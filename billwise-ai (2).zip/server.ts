import "dotenv/config";
import express, { type Request, type Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, ThinkingLevel, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";
import { extractTextItems, getDocumentProxy, inspectPages } from "unpdf";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const MODEL_NAME = "gemini-4-hydrogen";
const FALLBACK_MODEL_NAME = "gemini-3.1-flash-lite";

const ALLOWED_MIME_TYPES = new Set([
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
]);

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured in environment secrets.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function withRetry<T>(fn: () => Promise<T>, maxRetries = 2): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err: unknown) {
      lastError = err;
      const msg = err instanceof Error ? err.message : String(err);
      const isTransient =
        msg.includes("503") ||
        msg.includes("500") ||
        msg.includes("UNAVAILABLE") ||
        msg.includes("DEADLINE_EXCEEDED");
      if (!isTransient || attempt === maxRetries) {
        throw err;
      }
      await new Promise((resolve) => setTimeout(resolve, 600 * (attempt + 1)));
    }
  }
  throw lastError;
}

function isQuotaError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return msg.includes("RESOURCE_EXHAUSTED") || msg.includes("429");
}

async function generateWithModelFallback(
  ai: GoogleGenAI,
  request: {
    contents: unknown;
    systemInstruction: string;
    responseSchema: Record<string, unknown>;
  }
) {
  try {
    return await withRetry(() =>
      ai.models.generateContent({
        model: MODEL_NAME,
        contents: request.contents as never,
        config: {
          systemInstruction: request.systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: "application/json",
          responseSchema: request.responseSchema as never,
        },
      })
    );
  } catch (err) {
    if (!isQuotaError(err)) {
      throw err;
    }
    console.warn(
      `Primary model ${MODEL_NAME} quota exhausted (429); falling back to ${FALLBACK_MODEL_NAME}.`
    );
    return await withRetry(() =>
      ai.models.generateContent({
        model: FALLBACK_MODEL_NAME,
        contents: request.contents as never,
        config: {
          systemInstruction: request.systemInstruction,
          thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
          responseMimeType: "application/json",
          responseSchema: request.responseSchema as never,
        },
      })
    );
  }
}

function formatApiError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : "Unexpected server error.";
  if (raw.includes("GEMINI_API_KEY is not configured")) {
    return {
      status: 500,
      message: "Gemini API key is missing. Please verify it in Settings > Secrets.",
    };
  }
  if (raw.includes("API_KEY_INVALID") || raw.includes("PERMISSION_DENIED") || raw.includes("403")) {
    return {
      status: 403,
      message: "API key permission error. Please check your Gemini API key in Settings > Secrets.",
    };
  }
  if (raw.includes("RESOURCE_EXHAUSTED") || raw.includes("429")) {
    const isDailyLimit =
      raw.includes("PerDay") || raw.includes("per day") || raw.includes("limit: 20");
    return {
      status: 429,
      message: isDailyLimit
        ? "Daily free-tier Gemini API quota exceeded. Please wait for the quota reset or select a billing-enabled API key in Settings > Secrets."
        : "Rate limit reached. Please wait a moment and try again.",
    };
  }
  if (raw.includes("400") || raw.includes("INVALID_ARGUMENT")) {
    return {
      status: 400,
      message: "The uploaded file could not be processed. Try a clearer PDF or image (PNG/JPG/WEBP).",
    };
  }
  return { status: 500, message: raw };
}

function languageInstructionText(lang: string): string {
  switch (lang) {
    case "te":
      return "Write the summary in natural, clear Telugu script (తెలుగు). Keep numbers, consumer IDs, and currency amounts accurate.";
    case "hi":
      return "Write the summary in natural, clear Hindi using Devanagari script (हिन्दी). Keep numbers, consumer IDs, and currency amounts accurate.";
    case "tenglish":
      return "Write the summary in natural Tenglish (conversational Telugu written in English/Latin letters, e.g., 'Mee electricity bill total ₹1,450 undi, due date 24 Nov.'). Keep numbers and labels accurate.";
    case "en":
    case "auto":
    default:
      return "Write the summary in clear, everyday English.";
  }
}

async function extractEmbeddedPdfText(pdfBuffer: Buffer): Promise<{
  isTextBased: boolean;
  text: string;
  totalPages: number;
}> {
  let pdf: Awaited<ReturnType<typeof getDocumentProxy>> | null = null;
  try {
    pdf = await getDocumentProxy(new Uint8Array(pdfBuffer));
    const [inspection, itemsResult] = await Promise.all([
      inspectPages(pdf),
      extractTextItems(pdf),
    ]);

    const pageTexts: string[] = [];
    for (let p = 0; p < itemsResult.items.length; p++) {
      const pageItems = itemsResult.items[p].filter((it) => it.str.trim().length > 0);
      if (pageItems.length === 0) continue;

      // Sort top-to-bottom (y descending in PDF coordinates) then left-to-right (x ascending)
      pageItems.sort((a, b) => {
        const yDiff = b.y - a.y;
        const tol = Math.max(4, Math.min(a.height || 10, b.height || 10) * 0.45);
        if (Math.abs(yDiff) > tol) return yDiff;
        return a.x - b.x;
      });

      const lines: string[] = [];
      let currentRowY: number | null = null;
      let currentTol = 5;
      let rowTokens: Array<{ x: number; text: string }> = [];

      const flushRow = () => {
        if (rowTokens.length === 0) return;
        rowTokens.sort((a, b) => a.x - b.x);
        lines.push(rowTokens.map((t) => t.text).join("  "));
        rowTokens = [];
      };

      for (const item of pageItems) {
        const tol = Math.max(4, (item.height || item.fontSize || 10) * 0.45);
        if (currentRowY === null || Math.abs(item.y - currentRowY) <= Math.max(currentTol, tol)) {
          if (currentRowY === null) {
            currentRowY = item.y;
            currentTol = tol;
          }
          rowTokens.push({ x: item.x, text: item.str.trim() });
        } else {
          flushRow();
          currentRowY = item.y;
          currentTol = tol;
          rowTokens.push({ x: item.x, text: item.str.trim() });
        }
      }
      flushRow();

      pageTexts.push(`--- Page ${p + 1} ---\n${lines.join("\n")}`);
    }

    const mergedText = pageTexts.join("\n\n").trim();
    const visibleTextLength = inspection.pages.reduce(
      (sum, pg) => sum + Math.max(0, pg.textLength - pg.invisibleTextLength),
      0
    );
    const alnumCount = (mergedText.match(/[\p{L}\p{N}]/gu) || []).length;
    const replacementCount = (mergedText.match(/\uFFFD/g) || []).length;
    const garbledRatio = mergedText.length > 0 ? replacementCount / mergedText.length : 1;

    const isTextBased =
      alnumCount >= 60 && visibleTextLength >= 60 && garbledRatio < 0.08;

    return {
      isTextBased,
      text: mergedText,
      totalPages: itemsResult.totalPages,
    };
  } catch (err) {
    console.warn("Embedded PDF text inspection failed, falling back to PDF OCR:", err);
    return { isTextBased: false, text: "", totalPages: 0 };
  } finally {
    if (pdf && "cleanup" in pdf && typeof pdf.cleanup === "function") {
      try {
        await pdf.cleanup();
      } catch {
        // Ignore cleanup errors
      }
    }
  }
}

interface AnalyzeBillBody {
  fileName?: string;
  mimeType?: string;
  originalMimeType?: string;
  base64Data?: string;
  slotId?: "bill1" | "bill2";
  slotLabel?: string;
  languagePreference?: string;
  preprocessingApplied?: string[];
}

type EditableBillFieldKey =
  | "utilityProvider"
  | "consumerName"
  | "consumerNumber"
  | "serviceCategory"
  | "billNumber"
  | "billDate"
  | "billingPeriod"
  | "dueDate"
  | "disconnectionDate"
  | "previousReading"
  | "currentReading"
  | "unitsConsumed"
  | "fixedCharges"
  | "energyCharges"
  | "taxesAndAdditionalCharges"
  | "totalAmountPayable";

interface ChatBillInput {
  slotId: string;
  slotLabel: string;
  fileName: string;
  extractionMethod?: string;
  ocrConfidence?: "High" | "Medium" | "Low" | null;
  documentConfidenceNote?: string | null;
  isElectricityBill: boolean;
  utilityProvider: string | null;
  consumerName: string | null;
  consumerNumber: string | null;
  serviceCategory: string | null;
  billNumber: string | null;
  billDate: string | null;
  billingPeriod: string | null;
  dueDate: string | null;
  disconnectionDate: string | null;
  previousReading: string | null;
  currentReading: string | null;
  unitsConsumed: string | null;
  fixedCharges: string | null;
  energyCharges: string | null;
  taxesAndAdditionalCharges: string | null;
  totalAmountPayable: string | null;
  chargesBreakdown: Array<{
    name: string;
    amount: string;
    simpleExplanation: string;
  }>;
  unavailableFields: string[];
  verifiedValues?: Partial<Record<EditableBillFieldKey, string | null>>;
  userCorrectedFields?: string[];
  rawOcrText: string;
}

type DomainCategory =
  | "ELECTRICITY_BILL_RELATED"
  | "ELECTRICITY_CONCEPT_RELATED"
  | "GENERAL_UNRELATED"
  | "UNKNOWN";

interface ChatBody {
  message?: string;
  languagePreference?: "auto" | "en" | "te" | "hi" | "tenglish";
  bills?: ChatBillInput[];
  history?: Array<{
    role: "user" | "assistant";
    content: string;
  }>;
}

const OUT_OF_SCOPE_REPLIES: Record<"English" | "Telugu" | "Tenglish" | "Hindi", string> = {
  English:
    "I'm BillWise AI, an electricity bill understanding chatbot. I can help you understand your electricity bill, charges, units, due date, and bill comparison.",
  Telugu:
    "నేను BillWise AI, విద్యుత్ బిల్లులను అర్థం చేసుకోవడానికి రూపొందించిన చాట్బాట్ను. మీ బిల్లు మొత్తం, ఛార్జీలు, యూనిట్లు, చివరి తేదీ మరియు బిల్లుల పోలిక గురించి సహాయం చేయగలను.",
  Tenglish:
    "Nenu BillWise AI, electricity bills ardham chesukovadaniki design chesina chatbot. Mee bill amount, charges, units, due date, bill comparison gurinchi help chesthanu.",
  Hindi:
    "मैं BillWise AI हूँ, बिजली बिल समझने के लिए बनाया गया चैटबॉट। मैं बिल की राशि, शुल्क, यूनिट, अंतिम तारीख और बिलों की तुलना समझने में मदद कर सकता हूँ।",
};

function resolveEffectiveReplyLanguage(
  languagePreference: ChatBody["languagePreference"],
  detectedLanguage: unknown,
  message: string
): "English" | "Telugu" | "Tenglish" | "Hindi" {
  if (languagePreference === "en") return "English";
  if (languagePreference === "te") return "Telugu";
  if (languagePreference === "tenglish") return "Tenglish";
  if (languagePreference === "hi") return "Hindi";

  if (/[\u0C00-\u0C7F]/.test(message)) return "Telugu";
  if (/[\u0900-\u097F]/.test(message)) return "Hindi";

  if (
    detectedLanguage === "English" ||
    detectedLanguage === "Telugu" ||
    detectedLanguage === "Tenglish" ||
    detectedLanguage === "Hindi"
  ) {
    return detectedLanguage;
  }
  return "English";
}

function isFieldVerified(b: ChatBillInput, key: EditableBillFieldKey): boolean {
  return Boolean(
    b.verifiedValues && Object.prototype.hasOwnProperty.call(b.verifiedValues, key)
  );
}

function getEffectiveField(b: ChatBillInput, key: EditableBillFieldKey): string | null {
  if (isFieldVerified(b, key)) {
    return b.verifiedValues?.[key] ?? null;
  }
  return b[key] ?? null;
}

function formatFieldWithProvenance(
  b: ChatBillInput,
  key: EditableBillFieldKey
): string {
  const original = b[key] ?? null;
  if (isFieldVerified(b, key)) {
    const verified = b.verifiedValues?.[key] ?? null;
    return `${verified ?? "UNAVAILABLE"} [USER-VERIFIED | Original OCR was: ${original ?? "UNAVAILABLE"}]`;
  }
  return original ?? "UNAVAILABLE";
}

function parseNumericValue(raw: string | null | undefined): number | null {
  if (!raw) return null;
  // Normalize minus sign placed before currency symbol, e.g. "-₹50.00" -> "₹-50.00"
  const cleaned = raw
    .replace(/,/g, "")
    .trim()
    .replace(/^(-)\s*(?:₹|Rs\.?|INR|\$|€|£)\s*/i, "-");
  const matches = cleaned.match(/-?\d+(?:\.\d+)?/g);
  if (!matches || matches.length === 0) return null;
  if (matches.length === 1) {
    const num = Number(matches[0]);
    return Number.isFinite(num) ? num : null;
  }
  // Handle values like "₹145.00 (Duty ₹85 + Customer ₹60)" or "320 kWh (Tier 1: 200)"
  const leadingMatch = cleaned.match(
    /^(?:₹|Rs\.?|INR|\$|€|£)?\s*(-?\d+(?:\.\d+)?)\s*(?:kWh|units?|kvah)?\s*\(/i
  );
  if (leadingMatch) {
    const num = Number(leadingMatch[1]);
    return Number.isFinite(num) ? num : null;
  }
  return null;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function parseFlexibleDateMs(raw: string): number | null {
  const s = raw.trim();
  if (!s) return null;

  // Match DD/MM/YYYY, DD-MM-YYYY, or DD.MM.YYYY
  const dmy = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/);
  if (dmy) {
    const day = Number(dmy[1]);
    const month = Number(dmy[2]);
    let year = Number(dmy[3]);
    if (year < 100) year += 2000;
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      const utc = Date.UTC(year, month - 1, day);
      if (!Number.isNaN(utc)) return utc;
    }
  }

  // Match YYYY-MM-DD or YYYY/MM/DD
  const ymd = s.match(/^(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})$/);
  if (ymd) {
    const year = Number(ymd[1]);
    const month = Number(ymd[2]);
    const day = Number(ymd[3]);
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      const utc = Date.UTC(year, month - 1, day);
      if (!Number.isNaN(utc)) return utc;
    }
  }

  const parsed = Date.parse(s);
  return Number.isNaN(parsed) ? null : parsed;
}

function tryParseBillDateMs(b: ChatBillInput): number | null {
  const candidates = [
    getEffectiveField(b, "billDate"),
    getEffectiveField(b, "dueDate"),
    getEffectiveField(b, "billingPeriod"),
  ];
  for (const raw of candidates) {
    if (!raw) continue;
    const direct = parseFlexibleDateMs(raw);
    if (direct !== null) return direct;
    // Split ranges like "01-08-2026 to 31-08-2026" or "01 Aug 2026 - 31 Aug 2026"
    const parts = raw.split(/\s+to\s+|\s+[–—-]\s+/i);
    const tail = parts[parts.length - 1]?.trim();
    if (tail) {
      const tailMs = parseFlexibleDateMs(tail);
      if (tailMs !== null) return tailMs;
    }
  }
  return null;
}

function buildMissingInfoAudit(b: ChatBillInput): string {
  const checks: Array<{ key: EditableBillFieldKey; label: string; impact: string }> = [
    {
      key: "utilityProvider",
      label: "Electricity Provider",
      impact: "Cannot verify which utility board issued the bill.",
    },
    {
      key: "consumerNumber",
      label: "Consumer Number",
      impact: "Cannot confirm the account/service connection ID.",
    },
    {
      key: "billingPeriod",
      label: "Billing Period",
      impact: "Cannot verify exact billing cycle start and end dates.",
    },
    {
      key: "dueDate",
      label: "Due Date",
      impact: "Cannot answer when payment is due without late fees.",
    },
    {
      key: "disconnectionDate",
      label: "Disconnection Date",
      impact: "Cannot state the disconnection deadline.",
    },
    {
      key: "previousReading",
      label: "Previous Meter Reading",
      impact: "Cannot independently verify units consumed from meter readings.",
    },
    {
      key: "currentReading",
      label: "Current Meter Reading",
      impact: "Cannot independently verify units consumed from meter readings.",
    },
    {
      key: "unitsConsumed",
      label: "Units Consumed",
      impact: "Cannot report total kWh usage, average cost per unit, or consumption % change.",
    },
    {
      key: "fixedCharges",
      label: "Fixed Charges",
      impact: "Cannot separate fixed monthly fees from usage charges.",
    },
    {
      key: "energyCharges",
      label: "Energy Charges",
      impact: "Cannot isolate unit-consumption charges or energy cost per unit.",
    },
    {
      key: "taxesAndAdditionalCharges",
      label: "Taxes & Additional Charges",
      impact: "Cannot isolate taxes, duties, or surcharges.",
    },
    {
      key: "totalAmountPayable",
      label: "Total Amount Payable",
      impact: "Cannot state the final bill total or verify charge sum math.",
    },
  ];

  const missingLines: string[] = [];
  for (const c of checks) {
    if (!getEffectiveField(b, c.key)) {
      missingLines.push(`- Missing ${c.label}: ${c.impact}`);
    }
  }

  return missingLines.length > 0
    ? missingLines.join("\n")
    : "- All 12 core bill fields are available.";
}

function buildSingleBillMathAudit(b: ChatBillInput): string {
  const notes: string[] = [];

  const prev = parseNumericValue(getEffectiveField(b, "previousReading"));
  const curr = parseNumericValue(getEffectiveField(b, "currentReading"));
  const units = parseNumericValue(getEffectiveField(b, "unitsConsumed"));
  if (prev !== null && curr !== null) {
    const readingDiff = round2(curr - prev);
    if (units !== null) {
      const unitDelta = round2(units - readingDiff);
      if (Math.abs(unitDelta) < 0.01) {
        notes.push(
          `Meter Reading Check [Calculated]: Current (${curr}) - Previous (${prev}) = ${readingDiff} units, matching Units Consumed (${units}) exactly.`
        );
      } else {
        notes.push(
          `Meter Reading Check [Calculated]: Current (${curr}) - Previous (${prev}) = ${readingDiff}, whereas Units Consumed is ${units} (difference of ${unitDelta}; could reflect a meter multiplier/CT factor or OCR reading difference if not printed).`
        );
      }
    } else {
      notes.push(
        `Meter Reading Check [Calculated]: Current (${curr}) - Previous (${prev}) = ${readingDiff}, while Units Consumed field is unavailable.`
      );
    }
  } else {
    notes.push("Meter Reading Check: Cannot verify (previous or current reading unavailable).");
  }

  const total = parseNumericValue(getEffectiveField(b, "totalAmountPayable"));
  const fixed = parseNumericValue(getEffectiveField(b, "fixedCharges"));
  const energy = parseNumericValue(getEffectiveField(b, "energyCharges"));
  const taxes = parseNumericValue(getEffectiveField(b, "taxesAndAdditionalCharges"));

  if (units !== null && units > 0) {
    const perUnitParts: string[] = [];
    if (total !== null) {
      perUnitParts.push(`Overall avg cost/unit = ${round2(total / units)} per unit`);
    }
    if (energy !== null) {
      perUnitParts.push(`Energy-only avg rate/unit = ${round2(energy / units)} per unit`);
    }
    if (perUnitParts.length > 0) {
      notes.push(`Unit Cost [Calculated]: ${perUnitParts.join("; ")}.`);
    }
  }

  if (total !== null && total > 0) {
    const shares: string[] = [];
    if (energy !== null) shares.push(`Energy Charges: ${round2((energy / total) * 100)}%`);
    if (fixed !== null) shares.push(`Fixed Charges: ${round2((fixed / total) * 100)}%`);
    if (taxes !== null)
      shares.push(`Taxes & Additional Charges: ${round2((taxes / total) * 100)}%`);
    if (shares.length > 0) {
      notes.push(`Charge Shares of Total (${total}) [Calculated]: ${shares.join(", ")}.`);
    }
  }

  const breakdown = Array.isArray(b.chargesBreakdown) ? b.chargesBreakdown : [];
  const itemNumbers = breakdown
    .map((c) => ({ name: c.name, val: parseNumericValue(c.amount) }))
    .filter((c): c is { name: string; val: number } => c.val !== null);

  const hasExplicitRoundItem = itemNumbers.some((item) => /round/i.test(item.name));

  if (total !== null && itemNumbers.length > 0 && itemNumbers.length === breakdown.length) {
    const breakdownSum = round2(itemNumbers.reduce((s, x) => s + x.val, 0));
    const breakdownExpr = itemNumbers.map((x) => `${x.name} (${x.val})`).join(" + ");
    const diff = round2(total - breakdownSum);
    if (Math.abs(diff) < 0.01) {
      notes.push(
        `Itemized Charges Sum Verification [Calculated]: ${breakdownExpr} = ${breakdownSum}, which matches Total Amount Payable (${total}) exactly${hasExplicitRoundItem ? " (includes explicit rounding line item)" : ""}.`
      );
    } else if (Math.abs(diff) <= 1.5) {
      notes.push(
        `Itemized Charges Sum Verification [Calculated]: ${breakdownExpr} = ${breakdownSum}, compared to Total Amount Payable (${total}) — small rounding difference of ${diff >= 0 ? "+" : ""}${diff}.`
      );
    } else {
      notes.push(
        `Itemized Charges Sum Verification [Calculated]: ${breakdownExpr} = ${breakdownSum}, compared to Total Amount Payable (${total}) — difference of ${diff >= 0 ? "+" : ""}${diff} (may reflect arrears, credits, subsidies, or unextracted line items on the bill).`
      );
    }
  }

  if (total !== null && fixed !== null && energy !== null && taxes !== null) {
    const coreSum = round2(fixed + energy + taxes);
    const diff = round2(total - coreSum);
    if (Math.abs(diff) < 0.01) {
      notes.push(
        `Core Charges Sum Verification [Calculated]: Fixed (${fixed}) + Energy (${energy}) + Taxes & Additional (${taxes}) = ${coreSum}, matching Total Amount Payable (${total}) exactly.`
      );
    } else if (Math.abs(diff) <= 1.5) {
      notes.push(
        `Core Charges Sum Verification [Calculated]: Fixed (${fixed}) + Energy (${energy}) + Taxes & Additional (${taxes}) = ${coreSum} vs Total Amount Payable (${total}) — rounding difference of ${diff >= 0 ? "+" : ""}${diff}.`
      );
    } else {
      notes.push(
        `Core Charges Sum Verification [Calculated]: Fixed (${fixed}) + Energy (${energy}) + Taxes & Additional (${taxes}) = ${coreSum} vs Total Amount Payable (${total}) — difference of ${diff >= 0 ? "+" : ""}${diff} (check itemized breakdown for arrears, rebates, or additional fees).`
      );
    }
  } else if (
    !(total !== null && itemNumbers.length > 0 && itemNumbers.length === breakdown.length)
  ) {
    notes.push(
      "Charge Sum Verification: Cannot perform full sum verification because Total Amount Payable or one or more individual charge components are missing."
    );
  }

  return notes.join("\n");
}

type OcrValidationCategory =
  | "confusing_characters"
  | "unclear_value"
  | "amount_mismatch"
  | "consumption_inconsistency"
  | "date_inconsistency"
  | "incomplete_section";

interface OcrValidationIssue {
  id: string;
  severity: "error" | "warning" | "info";
  category: OcrValidationCategory;
  field: EditableBillFieldKey | "chargesBreakdown" | "rawOcrText" | "general";
  fieldLabel: string;
  originalOcrValue: string | null;
  suggestedValue: string | null;
  confusableMatches?: string[];
  message: string;
  needsUserConfirmation: boolean;
}

interface OcrValidationResult {
  status: "valid" | "needs_review" | "incomplete";
  hasConfusingCharacters: boolean;
  hasUnclearValues: boolean;
  hasAmountMismatch: boolean;
  hasConsumptionInconsistency: boolean;
  hasDateInconsistency: boolean;
  hasIncompleteSections: boolean;
  issues: OcrValidationIssue[];
  incompleteSections: string[];
  summaryNote: string;
}

const CONFUSABLE_CHAR_MAP: Record<string, string> = {
  O: "0",
  o: "0",
  I: "1",
  l: "1",
  S: "5",
  B: "8",
};

const MONTH_NAME_REGEX =
  /^(?:jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december|to)$/i;

function fixConfusableToken(token: string): {
  fixed: string;
  matches: string[];
} {
  const matches: string[] = [];
  let fixed = "";
  for (const ch of token) {
    if (Object.prototype.hasOwnProperty.call(CONFUSABLE_CHAR_MAP, ch)) {
      const replacement = CONFUSABLE_CHAR_MAP[ch];
      fixed += replacement;
      const desc = `${ch}→${replacement}`;
      if (!matches.includes(desc)) matches.push(desc);
    } else {
      fixed += ch;
    }
  }
  return { fixed, matches };
}

function detectConfusableCharactersInField(
  raw: string,
  kind: "amount" | "number" | "date"
): { suggestedValue: string; matches: string[] } | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  const allMatches: string[] = [];

  if (kind === "date") {
    // Process whitespace-separated segments; ignore month words like "Aug", "Sep", "Oct", "to"
    const parts = trimmed.split(/(\s+)/);
    const rebuilt = parts
      .map((part) => {
        if (/^\s+$/.test(part) || MONTH_NAME_REGEX.test(part)) return part;
        // Split by date separators so e.g. "16/I0/2026" or "O5-Sep-2026" is handled segment-by-segment
        return part
          .split(/([\/.\-])/)
          .map((seg) => {
            if (
              seg === "/" ||
              seg === "." ||
              seg === "-" ||
              MONTH_NAME_REGEX.test(seg)
            ) {
              return seg;
            }
            if (/^[0-9OolISB]+$/.test(seg) && /[OolISB]/.test(seg)) {
              const { fixed, matches } = fixConfusableToken(seg);
              for (const m of matches) allMatches.push(`${m} in '${seg}'`);
              return fixed;
            }
            return seg;
          })
          .join("");
      })
      .join("");

    return allMatches.length > 0
      ? { suggestedValue: rebuilt, matches: allMatches }
      : null;
  }

  // Amount or numeric reading/unit field:
  // Tokenize preserving spaces, check numeric-like tokens (ignoring currency prefixes & unit words)
  const parts = trimmed.split(/(\s+)/);
  const rebuilt = parts
    .map((part) => {
      if (/^\s+$/.test(part)) return part;
      if (
        /^(?:₹|Rs\.?|INR|\$|€|£|kWh|kVAh|kW|kVA|units?|unit)$/i.test(part)
      ) {
        return part;
      }
      // Handle leading currency attached to number, e.g., "₹1,O85.00" or "Rs.2S0" or "-₹B0"
      const m = part.match(
        /^(-?(?:₹|Rs\.?|INR|\$|€|£)?-?)([0-9OolISB][0-9OolISB,.]*)(.*)$/i
      );
      if (m) {
        const prefix = m[1];
        const numBody = m[2];
        const suffix = m[3];
        // Only treat suffix as unit if empty or valid unit label
        const suffixOk =
          !suffix || /^(?:kWh|kVAh|kW|kVA|units?|u|\/-)?$/i.test(suffix);
        if (
          suffixOk &&
          /[OolISB]/.test(numBody) &&
          (/[0-9]/.test(numBody) || prefix.length > 0)
        ) {
          const { fixed, matches } = fixConfusableToken(numBody);
          for (const desc of matches) allMatches.push(`${desc} in '${part}'`);
          return `${prefix}${fixed}${suffix}`;
        }
      }
      return part;
    })
    .join("");

  return allMatches.length > 0
    ? { suggestedValue: rebuilt, matches: allMatches }
    : null;
}

function parseBillingPeriodRange(
  raw: string | null
): { startMs: number | null; endMs: number | null } {
  if (!raw) return { startMs: null, endMs: null };
  const parts = raw.split(/\s+to\s+|\s+[–—-]\s+/i);
  if (parts.length >= 2) {
    return {
      startMs: parseFlexibleDateMs(parts[0]),
      endMs: parseFlexibleDateMs(parts[parts.length - 1]),
    };
  }
  return { startMs: null, endMs: parseFlexibleDateMs(raw) };
}

function getLocalizedValidationSummary(
  lang: string,
  issueCount: number,
  status: OcrValidationResult["status"]
): string {
  const norm = lang === "te" || lang === "hi" || lang === "tenglish" ? lang : "en";
  if (issueCount === 0 || status === "valid") {
    switch (norm) {
      case "te":
        return "బిల్లులోని మొత్తాలు, తేదీలు, మీటర్ రీడింగ్లు మరియు ఛార్జీల కూడిక అన్నీ సరిగ్గా ఉన్నాయి.";
      case "hi":
        return "बिल की राशि, तिथियाँ, मीटर रीडिंग और शुल्कों का योग सभी जाँच में सही पाए गए हैं।";
      case "tenglish":
        return "Bill loni amounts, dates, meter readings, mariyu charges sum anni validation checks pass ayyayi.";
      default:
        return "All extracted amounts, dates, meter readings, and charge sums passed validation checks.";
    }
  }
  switch (norm) {
    case "te":
      return `${issueCount} OCR / ధృవీకరణ ${issueCount > 1 ? "హెచ్చరికలు గుర్తించబడ్డాయి" : "హెచ్చరిక గుర్తించబడింది"}. అసలు OCR విలువలు భద్రపరచబడ్డాయి; దయచేసి సందేహాస్పద విలువలను నిర్ధారించండి.`;
    case "hi":
      return `${issueCount} OCR / सत्यापन चेतावनी${issueCount > 1 ? "याँ" : ""} मिली हैं। मूल OCR मान सुरक्षित रखे गए हैं; कृपया अनिश्चित मानों की पुष्टि करें।`;
    case "tenglish":
      return `${issueCount} OCR / validation warning${issueCount > 1 ? "s" : ""} gurthinchabadayi. Original OCR values preserve cheyabadayi; dayachesi doubtful values ni confirm cheyandi.`;
    default:
      return `Detected ${issueCount} OCR/validation notice${issueCount > 1 ? "s" : ""}. Original OCR values are preserved; please review and confirm any uncertain fields.`;
  }
}

function validateBillOcrAndConsistency(
  b: ChatBillInput,
  languagePreference = "en"
): OcrValidationResult {
  const issues: OcrValidationIssue[] = [];
  const incompleteSections: string[] = [];

  const fieldChecks: Array<{
    key: EditableBillFieldKey;
    label: string;
    kind: "amount" | "number" | "date";
  }> = [
    { key: "totalAmountPayable", label: "Total Amount Payable", kind: "amount" },
    { key: "energyCharges", label: "Energy Charges", kind: "amount" },
    { key: "fixedCharges", label: "Fixed Charges", kind: "amount" },
    {
      key: "taxesAndAdditionalCharges",
      label: "Taxes & Additional Charges",
      kind: "amount",
    },
    { key: "unitsConsumed", label: "Units Consumed", kind: "number" },
    { key: "previousReading", label: "Previous Meter Reading", kind: "number" },
    { key: "currentReading", label: "Current Meter Reading", kind: "number" },
    { key: "billDate", label: "Bill Date", kind: "date" },
    { key: "dueDate", label: "Due Date", kind: "date" },
    { key: "disconnectionDate", label: "Disconnection Date", kind: "date" },
    { key: "billingPeriod", label: "Billing Period", kind: "date" },
  ];

  const fieldsWithConfusables = new Set<string>();

  // 1 & 2. Confusing characters (0/O, 1/I, 5/S, 8/B) & unclear values on extracted/effective fields
  for (const fc of fieldChecks) {
    const val = getEffectiveField(b, fc.key);
    if (!val) continue;
    const userVerified = isFieldVerified(b, fc.key);

    // Check garbled / uncertain placeholder symbols
    if (/[\uFFFD?*]/.test(val)) {
      issues.push({
        id: `unclear_${fc.key}`,
        severity: "warning",
        category: "unclear_value",
        field: fc.key,
        fieldLabel: fc.label,
        originalOcrValue: b[fc.key] ?? val,
        suggestedValue: null,
        message: `${fc.label} contains unclear or illegible characters ("${val}"). Please confirm the exact value from your bill.`,
        needsUserConfirmation: !userVerified,
      });
      continue;
    }

    if (userVerified) {
      // User already explicitly confirmed or edited this field; do not re-nag for character confusion
      continue;
    }

    const confusable = detectConfusableCharactersInField(val, fc.kind);
    if (confusable) {
      fieldsWithConfusables.add(fc.key);
      issues.push({
        id: `confusable_${fc.key}`,
        severity: "warning",
        category: "confusing_characters",
        field: fc.key,
        fieldLabel: fc.label,
        originalOcrValue: b[fc.key] ?? val,
        suggestedValue: confusable.suggestedValue,
        confusableMatches: confusable.matches,
        message: `Possible OCR character confusion in ${fc.label} (${confusable.matches.join(", ")}). Original OCR: "${val}" → Suggested: "${confusable.suggestedValue}". Please confirm before relying on this value.`,
        needsUserConfirmation: true,
      });
      continue;
    }

    if (fc.kind === "amount" || fc.kind === "number") {
      if (parseNumericValue(val) === null) {
        issues.push({
          id: `unparseable_${fc.key}`,
          severity: "warning",
          category: "unclear_value",
          field: fc.key,
          fieldLabel: fc.label,
          originalOcrValue: b[fc.key] ?? val,
          suggestedValue: null,
          message: `${fc.label} ("${val}") could not be parsed as a clear single number. Please verify the printed value.`,
          needsUserConfirmation: true,
        });
      }
    } else if (fc.kind === "date") {
      if (fc.key === "billingPeriod") {
        const range = parseBillingPeriodRange(val);
        if (range.endMs === null && range.startMs === null) {
          issues.push({
            id: `unparseable_${fc.key}`,
            severity: "warning",
            category: "unclear_value",
            field: fc.key,
            fieldLabel: fc.label,
            originalOcrValue: b[fc.key] ?? val,
            suggestedValue: null,
            message: `${fc.label} ("${val}") is not a clear date format. Please verify the billing dates.`,
            needsUserConfirmation: true,
          });
        }
      } else if (parseFlexibleDateMs(val) === null) {
        issues.push({
          id: `unparseable_${fc.key}`,
          severity: "warning",
          category: "unclear_value",
          field: fc.key,
          fieldLabel: fc.label,
          originalOcrValue: b[fc.key] ?? val,
          suggestedValue: null,
          message: `${fc.label} ("${val}") does not match a valid calendar date. Please confirm the printed date.`,
          needsUserConfirmation: true,
        });
      }
    }
  }

  // Check chargesBreakdown items for confusables or unclear amounts
  const breakdown = Array.isArray(b.chargesBreakdown) ? b.chargesBreakdown : [];
  for (let i = 0; i < breakdown.length; i++) {
    const item = breakdown[i];
    if (!item?.amount) continue;
    const conf = detectConfusableCharactersInField(item.amount, "amount");
    if (conf) {
      issues.push({
        id: `confusable_breakdown_${i}`,
        severity: "warning",
        category: "confusing_characters",
        field: "chargesBreakdown",
        fieldLabel: `Charge Item: ${item.name}`,
        originalOcrValue: item.amount,
        suggestedValue: conf.suggestedValue,
        confusableMatches: conf.matches,
        message: `Possible OCR character confusion in "${item.name}" (${conf.matches.join(", ")}). Original: "${item.amount}" → Suggested: "${conf.suggestedValue}". Please confirm.`,
        needsUserConfirmation: true,
      });
    } else if (parseNumericValue(item.amount) === null) {
      issues.push({
        id: `unclear_breakdown_${i}`,
        severity: "warning",
        category: "unclear_value",
        field: "chargesBreakdown",
        fieldLabel: `Charge Item: ${item.name}`,
        originalOcrValue: item.amount,
        suggestedValue: null,
        message: `Charge "${item.name}" has an unclear amount ("${item.amount}"). Please verify from your bill.`,
        needsUserConfirmation: true,
      });
    }
  }

  // Scan rawOcrText lines with bill keywords for confusable numeric/date tokens not already caught or verified
  if (b.rawOcrText) {
    const verifiedOriginalTokens = new Set<string>();
    for (const fc of fieldChecks) {
      if (isFieldVerified(b, fc.key) && b[fc.key]) {
        const orig = String(b[fc.key]);
        for (const t of orig.split(/\s+/)) {
          const ct = t.replace(/^[₹:([]+|[.,:)\]]+$/g, "");
          if (ct) verifiedOriginalTokens.add(ct);
        }
      }
    }

    const rawLines = b.rawOcrText.split(/\r?\n/);
    const rawSuspicious: string[] = [];
    for (const line of rawLines) {
      if (
        !/(?:total|amount|payable|due|bill|reading|prev|curr|unit|kwh|fixed|energy|duty|tax|fac|charge|date|rs\.?|₹)/i.test(
          line
        )
      ) {
        continue;
      }
      const tokens = line.split(/\s+/);
      for (const tok of tokens) {
        const cleanTok = tok.replace(/^[₹:([]+|[.,:)\]]+$/g, "");
        if (verifiedOriginalTokens.has(cleanTok)) continue;
        if (
          /^[0-9OolISB][0-9OolISB.,:/-]*$/.test(cleanTok) &&
          /[0-9]/.test(cleanTok) &&
          /[OolISB]/.test(cleanTok)
        ) {
          const { fixed } = fixConfusableToken(cleanTok);
          const snippet = `'${cleanTok}' → '${fixed}'`;
          if (!rawSuspicious.includes(snippet)) rawSuspicious.push(snippet);
        }
      }
    }
    if (rawSuspicious.length > 0 && fieldsWithConfusables.size === 0) {
      issues.push({
        id: "confusable_raw_ocr",
        severity: "info",
        category: "confusing_characters",
        field: "rawOcrText",
        fieldLabel: "Raw OCR Text",
        originalOcrValue: rawSuspicious.slice(0, 4).join(", "),
        suggestedValue: null,
        confusableMatches: rawSuspicious.slice(0, 6),
        message: `Raw OCR text contains potentially confused digit/letter tokens (${rawSuspicious.slice(0, 4).join(", ")}). Please double-check extracted values.`,
        needsUserConfirmation: true,
      });
    }
  }

  // 3. Validate extracted bill amounts using available charge breakdowns
  const total = parseNumericValue(getEffectiveField(b, "totalAmountPayable"));
  const fixed = parseNumericValue(getEffectiveField(b, "fixedCharges"));
  const energy = parseNumericValue(getEffectiveField(b, "energyCharges"));
  const taxes = parseNumericValue(
    getEffectiveField(b, "taxesAndAdditionalCharges")
  );

  const itemNums = breakdown
    .map((c) => ({ name: c.name, val: parseNumericValue(c.amount) }))
    .filter((c): c is { name: string; val: number } => c.val !== null);

  if (
    total !== null &&
    itemNums.length > 0 &&
    itemNums.length === breakdown.length
  ) {
    const breakdownSum = round2(itemNums.reduce((s, x) => s + x.val, 0));
    const diff = round2(total - breakdownSum);
    if (Math.abs(diff) > 1.5) {
      issues.push({
        id: "amount_mismatch_breakdown",
        severity: "warning",
        category: "amount_mismatch",
        field: "totalAmountPayable",
        fieldLabel: "Total vs Itemized Charges",
        originalOcrValue: getEffectiveField(b, "totalAmountPayable"),
        suggestedValue: `${breakdownSum}`,
        message: `Charge breakdown items sum to ${breakdownSum}, which differs from Total Amount Payable (${total}) by ${diff >= 0 ? "+" : ""}${diff}. Please confirm whether an amount was misread or if arrears/credits are omitted.`,
        needsUserConfirmation: true,
      });
    }
  } else if (
    total !== null &&
    fixed !== null &&
    energy !== null &&
    taxes !== null
  ) {
    const coreSum = round2(fixed + energy + taxes);
    const diff = round2(total - coreSum);
    if (Math.abs(diff) > 1.5) {
      issues.push({
        id: "amount_mismatch_core",
        severity: "warning",
        category: "amount_mismatch",
        field: "totalAmountPayable",
        fieldLabel: "Total vs Core Charges",
        originalOcrValue: getEffectiveField(b, "totalAmountPayable"),
        suggestedValue: `${coreSum}`,
        message: `Fixed (${fixed}) + Energy (${energy}) + Taxes & Additional (${taxes}) = ${coreSum}, differing from Total Amount Payable (${total}) by ${diff >= 0 ? "+" : ""}${diff}. Please confirm these amounts.`,
        needsUserConfirmation: true,
      });
    }
  }

  // 4. Consumption & Meter Reading Logical Consistency
  const prev = parseNumericValue(getEffectiveField(b, "previousReading"));
  const curr = parseNumericValue(getEffectiveField(b, "currentReading"));
  const units = parseNumericValue(getEffectiveField(b, "unitsConsumed"));

  if (units !== null && units < 0) {
    issues.push({
      id: "negative_units",
      severity: "error",
      category: "consumption_inconsistency",
      field: "unitsConsumed",
      fieldLabel: "Units Consumed",
      originalOcrValue: getEffectiveField(b, "unitsConsumed"),
      suggestedValue: null,
      message: `Units Consumed (${units}) is negative, which is logically invalid. Please verify the printed units.`,
      needsUserConfirmation: true,
    });
  }

  if (prev !== null && curr !== null) {
    if (curr < prev) {
      issues.push({
        id: "reading_reversed",
        severity: "error",
        category: "consumption_inconsistency",
        field: "currentReading",
        fieldLabel: "Meter Readings",
        originalOcrValue: `Prev: ${prev}, Curr: ${curr}`,
        suggestedValue: null,
        message: `Current Meter Reading (${curr}) is less than Previous Meter Reading (${prev}). Unless the meter rolled over, one reading may have an OCR error—please confirm both readings.`,
        needsUserConfirmation: true,
      });
    } else {
      const readingDiff = round2(curr - prev);
      if (units !== null && Math.abs(units - readingDiff) > 0.01) {
        issues.push({
          id: "units_reading_mismatch",
          severity: "warning",
          category: "consumption_inconsistency",
          field: "unitsConsumed",
          fieldLabel: "Units vs Meter Readings",
          originalOcrValue: getEffectiveField(b, "unitsConsumed"),
          suggestedValue: `${readingDiff} kWh`,
          message: `Current (${curr}) - Previous (${prev}) = ${readingDiff} units, which does not match Units Consumed (${units}). Unless a meter multiplier applies, please confirm whether Units Consumed should be ${readingDiff}.`,
          needsUserConfirmation: true,
        });
      }
    }
  }

  if (energy !== null && units !== null) {
    if (energy > 0 && units === 0) {
      issues.push({
        id: "energy_without_units",
        severity: "warning",
        category: "consumption_inconsistency",
        field: "unitsConsumed",
        fieldLabel: "Units vs Energy Charges",
        originalOcrValue: getEffectiveField(b, "unitsConsumed"),
        suggestedValue: null,
        message: `Energy Charges are ${energy} while Units Consumed is 0. Please confirm both values.`,
        needsUserConfirmation: true,
      });
    } else if (units > 0 && energy === 0) {
      issues.push({
        id: "units_without_energy",
        severity: "warning",
        category: "consumption_inconsistency",
        field: "energyCharges",
        fieldLabel: "Energy Charges vs Units",
        originalOcrValue: getEffectiveField(b, "energyCharges"),
        suggestedValue: null,
        message: `Units Consumed are ${units} while Energy Charges are 0. Please confirm if a subsidy applies or if an OCR error occurred.`,
        needsUserConfirmation: true,
      });
    }
  }

  // 5. Billing Dates Logical Consistency
  const periodRange = parseBillingPeriodRange(
    getEffectiveField(b, "billingPeriod")
  );
  const billDateRaw = getEffectiveField(b, "billDate");
  const dueDateRaw = getEffectiveField(b, "dueDate");
  const discDateRaw = getEffectiveField(b, "disconnectionDate");
  const billMs = billDateRaw ? parseFlexibleDateMs(billDateRaw) : null;
  const dueMs = dueDateRaw ? parseFlexibleDateMs(dueDateRaw) : null;
  const discMs = discDateRaw ? parseFlexibleDateMs(discDateRaw) : null;

  if (periodRange.startMs !== null && periodRange.endMs !== null) {
    if (periodRange.startMs > periodRange.endMs) {
      issues.push({
        id: "period_reversed",
        severity: "error",
        category: "date_inconsistency",
        field: "billingPeriod",
        fieldLabel: "Billing Period",
        originalOcrValue: getEffectiveField(b, "billingPeriod"),
        suggestedValue: null,
        message: `Billing Period start date is later than end date ("${getEffectiveField(b, "billingPeriod")}"). Please confirm the billing dates.`,
        needsUserConfirmation: true,
      });
    } else {
      const days = round2((periodRange.endMs - periodRange.startMs) / 86400000);
      if (days > 75 || days < 1) {
        issues.push({
          id: "period_unusual_length",
          severity: "warning",
          category: "date_inconsistency",
          field: "billingPeriod",
          fieldLabel: "Billing Period",
          originalOcrValue: getEffectiveField(b, "billingPeriod"),
          suggestedValue: null,
          message: `Billing Period spans ${days} days ("${getEffectiveField(b, "billingPeriod")}"), which is unusual for a standard monthly/bi-monthly cycle. Please confirm.`,
          needsUserConfirmation: true,
        });
      }
    }
  }

  if (billMs !== null && dueMs !== null && dueMs < billMs) {
    issues.push({
      id: "due_before_bill_date",
      severity: "error",
      category: "date_inconsistency",
      field: "dueDate",
      fieldLabel: "Due Date vs Bill Date",
      originalOcrValue: dueDateRaw,
      suggestedValue: null,
      message: `Due Date (${dueDateRaw}) is earlier than Bill Date (${billDateRaw}), which is logically inconsistent. Please verify both dates.`,
      needsUserConfirmation: true,
    });
  }

  if (dueMs !== null && discMs !== null && discMs < dueMs) {
    issues.push({
      id: "disc_before_due_date",
      severity: "error",
      category: "date_inconsistency",
      field: "disconnectionDate",
      fieldLabel: "Disconnection Date vs Due Date",
      originalOcrValue: discDateRaw,
      suggestedValue: null,
      message: `Disconnection Date (${discDateRaw}) is earlier than Due Date (${dueDateRaw}), which is logically inconsistent. Please confirm.`,
      needsUserConfirmation: true,
    });
  }

  if (
    billMs !== null &&
    periodRange.endMs !== null &&
    billMs < periodRange.endMs - 2 * 86400000
  ) {
    issues.push({
      id: "bill_before_period_end",
      severity: "warning",
      category: "date_inconsistency",
      field: "billDate",
      fieldLabel: "Bill Date vs Billing Period",
      originalOcrValue: billDateRaw,
      suggestedValue: null,
      message: `Bill Date (${billDateRaw}) appears earlier than the Billing Period end ("${getEffectiveField(b, "billingPeriod")}"). Please confirm the printed dates.`,
      needsUserConfirmation: true,
    });
  }

  // 6. Unreadable or Incomplete Bill Sections
  if (b.ocrConfidence === "Low" || b.ocrConfidence === "Medium") {
    const note = `${b.ocrConfidence} OCR readability confidence${b.documentConfidenceNote ? ` (${b.documentConfidenceNote})` : ""}`;
    incompleteSections.push(note);
    issues.push({
      id: "low_ocr_confidence",
      severity: b.ocrConfidence === "Low" ? "error" : "warning",
      category: "incomplete_section",
      field: "general",
      fieldLabel: "Document Readability",
      originalOcrValue: null,
      suggestedValue: null,
      message: `${note}. Some printed digits or sections may be blurry—please verify key amounts and dates.`,
      needsUserConfirmation: false,
    });
  } else if (b.documentConfidenceNote) {
    incompleteSections.push(b.documentConfidenceNote);
    issues.push({
      id: "doc_confidence_note",
      severity: "warning",
      category: "incomplete_section",
      field: "general",
      fieldLabel: "Document Section Note",
      originalOcrValue: null,
      suggestedValue: null,
      message: b.documentConfidenceNote,
      needsUserConfirmation: false,
    });
  }

  const coreRequired: Array<{ key: EditableBillFieldKey; label: string }> = [
    { key: "totalAmountPayable", label: "Total Amount Payable" },
    { key: "unitsConsumed", label: "Units Consumed" },
    { key: "dueDate", label: "Due Date" },
    { key: "billingPeriod", label: "Billing Period" },
    { key: "energyCharges", label: "Energy Charges" },
    { key: "previousReading", label: "Previous Meter Reading" },
    { key: "currentReading", label: "Current Meter Reading" },
  ];
  const missingCore = coreRequired
    .filter((f) => !getEffectiveField(b, f.key))
    .map((f) => f.label);

  if (missingCore.length > 0) {
    incompleteSections.push(`Missing/unreadable fields: ${missingCore.join(", ")}`);
    issues.push({
      id: "missing_core_fields",
      severity: "warning",
      category: "incomplete_section",
      field: "general",
      fieldLabel: "Incomplete Bill Sections",
      originalOcrValue: null,
      suggestedValue: null,
      message: `Some bill sections could not be extracted or were missing: ${missingCore.join(", ")}. BillWise AI will not guess these values.`,
      needsUserConfirmation: false,
    });
  }

  const hasConfusingCharacters = issues.some(
    (i) => i.category === "confusing_characters"
  );
  const hasUnclearValues = issues.some((i) => i.category === "unclear_value");
  const hasAmountMismatch = issues.some((i) => i.category === "amount_mismatch");
  const hasConsumptionInconsistency = issues.some(
    (i) => i.category === "consumption_inconsistency"
  );
  const hasDateInconsistency = issues.some(
    (i) => i.category === "date_inconsistency"
  );
  const hasIncompleteSections = incompleteSections.length > 0;

  const status: OcrValidationResult["status"] =
    issues.some((i) => i.severity === "error") ||
    hasConfusingCharacters ||
    hasUnclearValues ||
    hasAmountMismatch ||
    hasConsumptionInconsistency ||
    hasDateInconsistency
      ? "needs_review"
      : hasIncompleteSections
        ? "incomplete"
        : "valid";

  const summaryNote = getLocalizedValidationSummary(
    languagePreference,
    issues.length,
    status
  );

  return {
    status,
    hasConfusingCharacters,
    hasUnclearValues,
    hasAmountMismatch,
    hasConsumptionInconsistency,
    hasDateInconsistency,
    hasIncompleteSections,
    issues,
    incompleteSections,
    summaryNote,
  };
}

function buildOcrValidationAudit(b: ChatBillInput): string {
  const val = validateBillOcrAndConsistency(b);
  if (val.issues.length === 0) {
    return "- OCR Validation Status: All extracted amounts, dates, meter readings, and charge sums passed consistency checks.";
  }
  const lines = [`- OCR Validation Status: ${val.status} (${val.summaryNote})`];
  for (const issue of val.issues) {
    const sug = issue.suggestedValue
      ? ` | Suggested Correction (UNCONFIRMED): "${issue.suggestedValue}"`
      : "";
    lines.push(
      `  * [${issue.severity.toUpperCase()} | ${issue.category}] ${issue.fieldLabel} (Original OCR: "${issue.originalOcrValue ?? "Unavailable"}"${sug}): ${issue.message}`
    );
  }
  return lines.join("\n");
}

type ComparisonTrend =
  | "increased"
  | "decreased"
  | "unchanged"
  | "only_in_older"
  | "only_in_newer"
  | "unavailable"
  | "info";

interface ComparisonRow {
  key: string;
  label: string;
  category: "overview" | "meter" | "charges" | "itemized";
  olderDisplay: string | null;
  newerDisplay: string | null;
  olderNumeric: number | null;
  newerNumeric: number | null;
  difference: number | null;
  percentChange: number | null;
  trend: ComparisonTrend;
  note?: string;
}

interface BillComparisonResult {
  olderSlotId: "bill1" | "bill2";
  olderLabel: string;
  olderFileName: string;
  newerSlotId: "bill1" | "bill2";
  newerLabel: string;
  newerFileName: string;
  chronologyNote: string;
  meterContinuityNote: string | null;
  rows: ComparisonRow[];
  increasedCharges: ComparisonRow[];
  decreasedCharges: ComparisonRow[];
  unchangedCharges: ComparisonRow[];
  onlyInOlderCharges: ComparisonRow[];
  onlyInNewerCharges: ComparisonRow[];
  missingOrUnclearFields: Array<{
    billLabel: string;
    fieldLabel: string;
    reason: string;
  }>;
  clarityWarnings: string[];
  avgCostPerUnit: {
    older: number | null;
    newer: number | null;
    difference: number | null;
    percentChange: number | null;
    trend: ComparisonTrend;
  };
  chargeContributions: Array<{
    label: string;
    difference: number;
    shareOfTotalChangePct: number;
  }>;
}

function normalizeChargeName(name: string): string {
  return name
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\bcharges\b/g, "charge")
    .replace(/\btaxes\b/g, "tax")
    .replace(/\bfees\b/g, "fee")
    .replace(/\bduties\b/g, "duty")
    .replace(/\bsurcharges\b/g, "surcharge")
    .replace(/\s+/g, " ")
    .trim();
}

function computeBillComparison(bills: ChatBillInput[]): BillComparisonResult | null {
  if (bills.length < 2) return null;
  const [b1, b2] = bills;

  const d1 = tryParseBillDateMs(b1);
  const d2 = tryParseBillDateMs(b2);
  let older = b1;
  let newer = b2;
  let chronologyNote =
    "Date Order: Could not parse unambiguous bill dates; comparing Bill 1 -> Bill 2 directly.";

  if (d1 !== null && d2 !== null && d1 !== d2) {
    if (d1 < d2) {
      older = b1;
      newer = b2;
      chronologyNote = `Chronological Order [Inferred from printed dates]: ${b1.slotLabel} is earlier -> ${b2.slotLabel} is newer.`;
    } else {
      older = b2;
      newer = b1;
      chronologyNote = `Chronological Order [Inferred from printed dates]: ${b2.slotLabel} is earlier -> ${b1.slotLabel} is newer.`;
    }
  } else {
    // Fallback: check meter reading progression if dates are unavailable or equal
    const b1Curr = parseNumericValue(getEffectiveField(b1, "currentReading"));
    const b2Prev = parseNumericValue(getEffectiveField(b2, "previousReading"));
    const b2Curr = parseNumericValue(getEffectiveField(b2, "currentReading"));
    const b1Prev = parseNumericValue(getEffectiveField(b1, "previousReading"));
    if (b1Curr !== null && b2Prev !== null && Math.abs(b1Curr - b2Prev) < 0.01) {
      older = b1;
      newer = b2;
      chronologyNote = `Chronological Order [Inferred from meter readings]: ${b1.slotLabel} is earlier -> ${b2.slotLabel} is newer.`;
    } else if (b2Curr !== null && b1Prev !== null && Math.abs(b2Curr - b1Prev) < 0.01) {
      older = b2;
      newer = b1;
      chronologyNote = `Chronological Order [Inferred from meter readings]: ${b2.slotLabel} is earlier -> ${b1.slotLabel} is newer.`;
    }
  }

  const missingOrUnclearFields: BillComparisonResult["missingOrUnclearFields"] = [];
  const clarityWarnings: string[] = [];

  for (const bill of [older, newer]) {
    if (!bill.isElectricityBill) {
      clarityWarnings.push(
        `${bill.slotLabel} (${bill.fileName}) may not be an electricity utility bill.`
      );
    }
    if (bill.ocrConfidence === "Low" || bill.ocrConfidence === "Medium") {
      clarityWarnings.push(
        `${bill.slotLabel} has ${bill.ocrConfidence} OCR readability confidence${
          bill.documentConfidenceNote ? `: ${bill.documentConfidenceNote}` : "."
        }`
      );
    } else if (bill.documentConfidenceNote) {
      clarityWarnings.push(`${bill.slotLabel}: ${bill.documentConfidenceNote}`);
    }
  }

  const rows: ComparisonRow[] = [];

  const addInfoRow = (
    key: string,
    label: string,
    category: ComparisonRow["category"],
    field: EditableBillFieldKey
  ) => {
    const v1 = getEffectiveField(older, field);
    const v2 = getEffectiveField(newer, field);
    if (!v1) {
      missingOrUnclearFields.push({
        billLabel: older.slotLabel,
        fieldLabel: label,
        reason: "Not found or unreadable in uploaded bill",
      });
    }
    if (!v2) {
      missingOrUnclearFields.push({
        billLabel: newer.slotLabel,
        fieldLabel: label,
        reason: "Not found or unreadable in uploaded bill",
      });
    }
    rows.push({
      key,
      label,
      category,
      olderDisplay: v1,
      newerDisplay: v2,
      olderNumeric: null,
      newerNumeric: null,
      difference: null,
      percentChange: null,
      trend: !v1 || !v2 ? "unavailable" : "info",
    });
  };

  const addNumericRow = (
    key: string,
    label: string,
    category: ComparisonRow["category"],
    field: EditableBillFieldKey
  ): ComparisonRow => {
    const rawOlder = getEffectiveField(older, field);
    const rawNewer = getEffectiveField(newer, field);
    const v1 = parseNumericValue(rawOlder);
    const v2 = parseNumericValue(rawNewer);

    if (v1 === null) {
      missingOrUnclearFields.push({
        billLabel: older.slotLabel,
        fieldLabel: label,
        reason: rawOlder
          ? `Could not parse single numeric value from "${rawOlder}"`
          : "Not found or unreadable in uploaded bill",
      });
    }
    if (v2 === null) {
      missingOrUnclearFields.push({
        billLabel: newer.slotLabel,
        fieldLabel: label,
        reason: rawNewer
          ? `Could not parse single numeric value from "${rawNewer}"`
          : "Not found or unreadable in uploaded bill",
      });
    }

    let difference: number | null = null;
    let percentChange: number | null = null;
    let trend: ComparisonTrend = "unavailable";

    if (v1 !== null && v2 !== null) {
      difference = round2(v2 - v1);
      percentChange = v1 !== 0 ? round2((difference / v1) * 100) : null;
      trend =
        Math.abs(difference) < 0.01
          ? "unchanged"
          : difference > 0
            ? "increased"
            : "decreased";
    }

    const row: ComparisonRow = {
      key,
      label,
      category,
      olderDisplay: rawOlder,
      newerDisplay: rawNewer,
      olderNumeric: v1,
      newerNumeric: v2,
      difference,
      percentChange,
      trend,
    };
    rows.push(row);
    return row;
  };

  // Overview & Billing Period / Dates
  addInfoRow("billingPeriod", "Billing Period", "overview", "billingPeriod");
  addInfoRow("billDate", "Bill Date", "overview", "billDate");
  addInfoRow("dueDate", "Due Date", "overview", "dueDate");

  // Core Usage & Total
  const totalRow = addNumericRow(
    "totalAmountPayable",
    "Total Bill Amount",
    "charges",
    "totalAmountPayable"
  );
  const unitsRow = addNumericRow(
    "unitsConsumed",
    "Units Consumed",
    "meter",
    "unitsConsumed"
  );

  // Meter Readings
  const prevReadRow = addNumericRow(
    "previousReading",
    "Previous Meter Reading",
    "meter",
    "previousReading"
  );
  const currReadRow = addNumericRow(
    "currentReading",
    "Current Meter Reading",
    "meter",
    "currentReading"
  );

  let meterContinuityNote: string | null = null;
  if (currReadRow.olderNumeric !== null && prevReadRow.newerNumeric !== null) {
    const gap = round2(prevReadRow.newerNumeric - currReadRow.olderNumeric);
    if (Math.abs(gap) < 0.01) {
      meterContinuityNote = `Meter Reading Continuity [Verified]: ${older.slotLabel} Current Reading (${currReadRow.olderNumeric}) matches ${newer.slotLabel} Previous Reading (${prevReadRow.newerNumeric}) seamlessly.`;
    } else {
      meterContinuityNote = `Meter Reading Continuity [Gap/Mismatch]: ${older.slotLabel} Current Reading (${currReadRow.olderNumeric}) differs from ${newer.slotLabel} Previous Reading (${prevReadRow.newerNumeric}) by ${gap >= 0 ? "+" : ""}${gap} units.`;
    }
  }

  // Core Charges
  const energyRow = addNumericRow(
    "energyCharges",
    "Energy Charges",
    "charges",
    "energyCharges"
  );
  const fixedRow = addNumericRow(
    "fixedCharges",
    "Fixed Charges",
    "charges",
    "fixedCharges"
  );
  const taxesRow = addNumericRow(
    "taxesAndAdditionalCharges",
    "Taxes & Additional Charges",
    "charges",
    "taxesAndAdditionalCharges"
  );

  // Average Cost per Unit
  let avgCostPerUnit: BillComparisonResult["avgCostPerUnit"] = {
    older: null,
    newer: null,
    difference: null,
    percentChange: null,
    trend: "unavailable",
  };
  if (
    unitsRow.olderNumeric !== null &&
    unitsRow.olderNumeric > 0 &&
    unitsRow.newerNumeric !== null &&
    unitsRow.newerNumeric > 0 &&
    totalRow.olderNumeric !== null &&
    totalRow.newerNumeric !== null
  ) {
    const cpu1 = round2(totalRow.olderNumeric / unitsRow.olderNumeric);
    const cpu2 = round2(totalRow.newerNumeric / unitsRow.newerNumeric);
    const cpuDelta = round2(cpu2 - cpu1);
    const cpuPct = cpu1 !== 0 ? round2((cpuDelta / cpu1) * 100) : null;
    avgCostPerUnit = {
      older: cpu1,
      newer: cpu2,
      difference: cpuDelta,
      percentChange: cpuPct,
      trend:
        Math.abs(cpuDelta) < 0.01
          ? "unchanged"
          : cpuDelta > 0
            ? "increased"
            : "decreased",
    };
    rows.push({
      key: "avgCostPerUnit",
      label: "Avg Cost per Unit (Calculated)",
      category: "charges",
      olderDisplay: `${cpu1}/unit`,
      newerDisplay: `${cpu2}/unit`,
      olderNumeric: cpu1,
      newerNumeric: cpu2,
      difference: cpuDelta,
      percentChange: cpuPct,
      trend: avgCostPerUnit.trend,
    });
  }

  // Contribution Shares of Total Bill Delta
  const chargeContributions: BillComparisonResult["chargeContributions"] = [];
  if (totalRow.difference !== null && Math.abs(totalRow.difference) > 0.01) {
    for (const entry of [energyRow, fixedRow, taxesRow]) {
      if (entry.difference !== null && Math.abs(entry.difference) > 0.01) {
        chargeContributions.push({
          label: entry.label,
          difference: entry.difference,
          shareOfTotalChangePct: round2((entry.difference / totalRow.difference) * 100),
        });
      }
    }
  }

  // Itemized Charges Breakdown (matched + only-in-one-bill charges)
  const breakdownOlder = Array.isArray(older.chargesBreakdown)
    ? older.chargesBreakdown
    : [];
  const breakdownNewer = Array.isArray(newer.chargesBreakdown)
    ? newer.chargesBreakdown
    : [];

  const olderMap = new Map<
    string,
    { name: string; amount: string; num: number | null; matched: boolean }
  >();
  for (const item of breakdownOlder) {
    const norm = normalizeChargeName(item.name);
    if (!norm) continue;
    const existing = olderMap.get(norm);
    const parsedNum = parseNumericValue(item.amount);
    if (!existing) {
      olderMap.set(norm, {
        name: item.name,
        amount: item.amount,
        num: parsedNum,
        matched: false,
      });
    } else if (existing.num !== null && parsedNum !== null) {
      existing.num = round2(existing.num + parsedNum);
      existing.amount = `${existing.amount} + ${item.amount}`;
    }
  }

  const itemizedRows: ComparisonRow[] = [];
  const seenNormKeys = new Set<string>();

  for (const item2 of breakdownNewer) {
    const norm = normalizeChargeName(item2.name);
    if (!norm) continue;
    const v2 = parseNumericValue(item2.amount);
    const match1 = olderMap.get(norm);

    if (match1) {
      match1.matched = true;
      seenNormKeys.add(norm);
      const v1 = match1.num;
      let difference: number | null = null;
      let percentChange: number | null = null;
      let trend: ComparisonTrend = "unavailable";

      if (v1 !== null && v2 !== null) {
        difference = round2(v2 - v1);
        percentChange = v1 !== 0 ? round2((difference / v1) * 100) : null;
        trend =
          Math.abs(difference) < 0.01
            ? "unchanged"
            : difference > 0
              ? "increased"
              : "decreased";
      }

      itemizedRows.push({
        key: `item_${norm}`,
        label: item2.name,
        category: "itemized",
        olderDisplay: match1.amount,
        newerDisplay: item2.amount,
        olderNumeric: v1,
        newerNumeric: v2,
        difference,
        percentChange,
        trend,
      });
    } else if (!seenNormKeys.has(norm)) {
      seenNormKeys.add(norm);
      itemizedRows.push({
        key: `item_${norm}`,
        label: item2.name,
        category: "itemized",
        olderDisplay: null,
        newerDisplay: item2.amount,
        olderNumeric: null,
        newerNumeric: v2,
        difference: v2,
        percentChange: null,
        trend: "only_in_newer",
        note: `Present only in ${newer.slotLabel}`,
      });
    }
  }

  for (const [norm, item1] of olderMap.entries()) {
    if (item1.matched) continue;
    itemizedRows.push({
      key: `item_${norm}`,
      label: item1.name,
      category: "itemized",
      olderDisplay: item1.amount,
      newerDisplay: null,
      olderNumeric: item1.num,
      newerNumeric: null,
      difference: item1.num !== null ? round2(-item1.num) : null,
      percentChange: null,
      trend: "only_in_older",
      note: `Present only in ${older.slotLabel}`,
    });
  }

  const filteredItemized = itemizedRows.filter((row) => {
    if (
      row.key === "item_energy charge" &&
      energyRow.olderNumeric !== null &&
      energyRow.newerNumeric !== null &&
      row.olderNumeric === energyRow.olderNumeric &&
      row.newerNumeric === energyRow.newerNumeric
    ) {
      return false;
    }
    if (
      row.key === "item_fixed charge" &&
      fixedRow.olderNumeric !== null &&
      fixedRow.newerNumeric !== null &&
      row.olderNumeric === fixedRow.olderNumeric &&
      row.newerNumeric === fixedRow.newerNumeric
    ) {
      return false;
    }
    return true;
  });

  filteredItemized.sort(
    (a, b) => Math.abs(b.difference ?? 0) - Math.abs(a.difference ?? 0)
  );
  rows.push(...filteredItemized);

  const chargeRows = rows.filter(
    (r) => r.category === "charges" || r.category === "itemized"
  );

  return {
    olderSlotId: older.slotId === "bill2" ? "bill2" : "bill1",
    olderLabel: older.slotLabel,
    olderFileName: older.fileName,
    newerSlotId: newer.slotId === "bill2" ? "bill2" : "bill1",
    newerLabel: newer.slotLabel,
    newerFileName: newer.fileName,
    chronologyNote,
    meterContinuityNote,
    rows,
    increasedCharges: chargeRows.filter((r) => r.trend === "increased"),
    decreasedCharges: chargeRows.filter((r) => r.trend === "decreased"),
    unchangedCharges: chargeRows.filter((r) => r.trend === "unchanged"),
    onlyInOlderCharges: chargeRows.filter((r) => r.trend === "only_in_older"),
    onlyInNewerCharges: chargeRows.filter((r) => r.trend === "only_in_newer"),
    missingOrUnclearFields,
    clarityWarnings,
    avgCostPerUnit,
    chargeContributions,
  };
}

function buildMultiBillComparisonAudit(bills: ChatBillInput[]): string {
  const cmp = computeBillComparison(bills);
  if (!cmp) return "";

  const lines: string[] = [
    `=== DETERMINISTIC COMPARISON ANALYTICS (${cmp.olderLabel} -> ${cmp.newerLabel}) ===`,
    cmp.chronologyNote,
  ];
  if (cmp.meterContinuityNote) {
    lines.push(cmp.meterContinuityNote);
  }

  for (const row of cmp.rows) {
    if (row.category === "overview") {
      lines.push(
        `- ${row.label}: ${cmp.olderLabel} = ${row.olderDisplay ?? "Not found"} | ${cmp.newerLabel} = ${row.newerDisplay ?? "Not found"}`
      );
      continue;
    }

    if (row.trend === "only_in_newer") {
      lines.push(
        `- ${row.label} [Only in ${cmp.newerLabel}]: ${cmp.olderLabel} = Not present -> ${cmp.newerLabel} = ${row.newerDisplay ?? "Unavailable"} (New charge added: +${row.difference ?? row.newerDisplay ?? "?"})`
      );
      continue;
    }

    if (row.trend === "only_in_older") {
      lines.push(
        `- ${row.label} [Only in ${cmp.olderLabel}]: ${cmp.olderLabel} = ${row.olderDisplay ?? "Unavailable"} -> ${cmp.newerLabel} = Not present (Not charged in ${cmp.newerLabel}; change: ${row.difference ?? "N/A"})`
      );
      continue;
    }

    if (row.olderNumeric !== null && row.newerNumeric !== null && row.difference !== null) {
      const pctStr =
        row.percentChange !== null
          ? ` (${row.percentChange >= 0 ? "+" : ""}${row.percentChange}%)`
          : "";
      lines.push(
        `- ${row.label} [Calculated]: ${cmp.olderLabel} = ${row.olderDisplay ?? row.olderNumeric} (${row.olderNumeric}) -> ${cmp.newerLabel} = ${row.newerDisplay ?? row.newerNumeric} (${row.newerNumeric}) | ${row.trend} by ${row.difference >= 0 ? "+" : ""}${row.difference}${pctStr}`
      );
    } else {
      lines.push(
        `- ${row.label} [Missing/Unclear]: ${cmp.olderLabel} = ${row.olderDisplay ?? "Not found"} | ${cmp.newerLabel} = ${row.newerDisplay ?? "Not found"} (cannot compute numeric difference)`
      );
    }
  }

  if (cmp.chargeContributions.length > 0) {
    lines.push(
      "Contribution to Total Bill Change [Calculated]: " +
        cmp.chargeContributions
          .map(
            (c) =>
              `${c.label}: ${c.difference >= 0 ? "+" : ""}${c.difference} (${c.shareOfTotalChangePct}% of total change)`
          )
          .join("; ")
    );
  }

  lines.push(
    `Charge Movement Summary: Increased (${cmp.increasedCharges.map((r) => r.label).join(", ") || "None"}); Decreased (${cmp.decreasedCharges.map((r) => r.label).join(", ") || "None"}); Unchanged (${cmp.unchangedCharges.map((r) => r.label).join(", ") || "None"}); Only in ${cmp.newerLabel} (${cmp.onlyInNewerCharges.map((r) => r.label).join(", ") || "None"}); Only in ${cmp.olderLabel} (${cmp.onlyInOlderCharges.map((r) => r.label).join(", ") || "None"}).`
  );

  if (cmp.missingOrUnclearFields.length > 0) {
    lines.push(
      "Missing or Unclear Comparison Fields:\n" +
        cmp.missingOrUnclearFields
          .map((m) => `  * ${m.billLabel} — ${m.fieldLabel}: ${m.reason}`)
          .join("\n")
    );
  }

  if (cmp.clarityWarnings.length > 0) {
    lines.push("Document Clarity / OCR Confidence Notes:\n  * " + cmp.clarityWarnings.join("\n  * "));
  }

  return lines.join("\n");
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "30mb" }));

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ status: "ok" });
  });

  app.post("/api/bills/analyze", async (req: Request, res: Response) => {
    try {
      const body = req.body as AnalyzeBillBody;
      const {
        fileName,
        mimeType,
        originalMimeType,
        base64Data,
        slotId,
        slotLabel,
        languagePreference,
        preprocessingApplied,
      } = body;

      if (!fileName || !mimeType || !base64Data) {
        res.status(400).json({ error: "Missing fileName, mimeType, or file data." });
        return;
      }

      const normalizedMime = mimeType === "image/jpg" ? "image/jpeg" : mimeType.toLowerCase();
      if (!ALLOWED_MIME_TYPES.has(normalizedMime)) {
        res.status(400).json({
          error: "Unsupported file format. Please upload a PDF, PNG, JPG, or WEBP electricity bill.",
        });
        return;
      }

      const ai = getAiClient();
      const langNote = languageInstructionText(languagePreference || "auto");

      let extractionMethod = "Image OCR";
      let directPdfText: string | null = null;

      if (normalizedMime === "application/pdf") {
        const pdfResult = await extractEmbeddedPdfText(Buffer.from(base64Data, "base64"));
        if (pdfResult.isTextBased) {
          directPdfText = pdfResult.text;
          extractionMethod = "Embedded PDF Text";
        } else {
          extractionMethod = "Scanned PDF OCR";
        }
      } else {
        extractionMethod =
          Array.isArray(preprocessingApplied) && preprocessingApplied.length > 0
            ? "Preprocessed Image OCR"
            : "Image OCR";
      }

      const extractionInstructions = `You are BillWise AI's OCR and NLP Electricity Bill Extraction Engine.
You support diverse electricity bill layouts across utility providers (tabular multi-column PDFs, regional Indian utility slips like TSSPDCL/APSPDCL/APEPDCL/BESCOM/MSEDCL/TNEB/UPPCL/BSES/Tata Power, thermal POS rolls, bilingual English/Telugu/Hindi bills, and international utility statements).

Your task is to:
1. ${
        directPdfText
          ? "Read the embedded PDF text supplied below and preserve it faithfully in 'rawOcrText'."
          : "Perform faithful, complete Optical Character Recognition (OCR) on the uploaded document (handling rotated/sideways scans, tables, thermal prints, and multi-column layouts) and transcribe all visible text, numbers, headers, tables, Telugu/Hindi/English labels, and dates into 'rawOcrText'."
      }
2. Determine if the document is actually an electricity/power utility bill ('isElectricityBill').
3. Extract all structured electricity bill entities strictly from what is visibly present in the document:
   - Electricity provider name ('utilityProvider')
   - Consumer name ('consumerName')
   - Consumer number / USC No / Service No / CA No ('consumerNumber')
   - Service / tariff category ('serviceCategory')
   - Bill number ('billNumber')
   - Bill date ('billDate')
   - Billing period ('billingPeriod')
   - Due date ('dueDate')
   - Disconnection date ('disconnectionDate')
   - Previous meter reading ('previousReading')
   - Current meter reading ('currentReading')
   - Units consumed ('unitsConsumed')
   - Fixed charges ('fixedCharges' — fixed/demand/minimum monthly charge)
   - Energy charges ('energyCharges' — variable consumption/unit slab charges)
   - Taxes and additional charges ('taxesAndAdditionalCharges' — electricity duty, GST/tax, customer charges, FAC/FPPCA, surcharge, cess, or combined total of taxes & extra fees if listed separately; include label details cleanly)
   - Total amount payable ('totalAmountPayable')
   - CRITICAL RULE: NEVER invent, estimate, guess, or fabricate missing values. If a field is not visible, illegible, or absent on the bill, set it to null and list its human-readable name in 'unavailableFields'.
   - OCR FIDELITY RULE: Never silently alter or auto-guess ambiguous/blurred characters (such as 0 vs O, 1 vs I/l, 5 vs S, 8 vs B). Transcribe what is visibly printed faithfully, and note any blurred or unreadable sections in 'documentConfidenceNote'.
   - For 'chargesBreakdown', list every visible charge, tax, fee, credit, or subsidy line item exactly as printed with its amount and a simple, beginner-friendly 1-sentence explanation.
   - Assess 'ocrConfidence' honestly ("High", "Medium", or "Low") based on document readability, sharpness, and completeness (use "High" for clear digital text, "Medium" if slightly blurry/skewed/faded, "Low" if heavily degraded or partially cut off), and note any factual visibility issues in 'documentConfidenceNote'.
4. Write 'initialSummary': a detailed, easy-to-understand structured bill breakdown in Markdown (NEVER write a paragraph!). Use ONLY headings, bullet points, and a Markdown table formatted like this:
   ### Quick Bill Overview
   - **Provider:** <value or "Not found in uploaded bill">
   - **Consumer Name & Number:** <values or "Not found in uploaded bill">
   - **Billing Period:** <value or "Not found in uploaded bill">
   - **Total Amount Payable:** <value or "Not found in uploaded bill">
   - **Due Date:** <value or "Not found in uploaded bill">
   - **Disconnection Date:** <value or "Not found in uploaded bill">

   ### Meter & Units Used
   - **Previous Reading:** <value or "Not found in uploaded bill">
   - **Current Reading:** <value or "Not found in uploaded bill">
   - **Total Units Consumed:** <value or "Not found in uploaded bill">

   ### Charges Breakdown (Simple Meaning)
   | Charge | Amount | Simple Explanation |
   | :--- | :--- | :--- |
   (include every extracted charge, tax, fee, or fixed/energy charge with its plain-language meaning)

   ### Missing Information
   - List any important details not found in the uploaded bill (or state "- All key bill details were found.").
5. Generate 'suggestedQuestions': 3–4 short, helpful questions a user can ask next based ONLY on the fields actually extracted from this bill (e.g., if dueDate exists, suggest asking about due date; if energyCharges/chargesBreakdown exist, suggest explaining charges; if unitsConsumed exists, suggest asking about units & cost per unit; if fields are missing, suggest asking what is missing). Write them in the target summary language.
   ${langNote}`;

      const contents = directPdfText
        ? `Extract structured electricity bill fields from the embedded text of "${fileName}" (${slotLabel || "Bill"}):\n\n${directPdfText.slice(0, 30000)}`
        : {
            parts: [
              {
                inlineData: {
                  mimeType: normalizedMime,
                  data: base64Data,
                },
              },
              {
                text: `Extract the full OCR text and structured electricity bill fields from "${fileName}" (${slotLabel || "Bill"}).`,
              },
            ],
          };

      const response = await generateWithModelFallback(ai, {
        contents,
        systemInstruction: extractionInstructions,
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isElectricityBill: {
              type: Type.BOOLEAN,
              description: "True if the document is an electricity/power utility bill, false otherwise.",
            },
            utilityProvider: {
              type: Type.STRING,
              nullable: true,
              description: "Electricity utility board or company name.",
            },
            consumerName: {
              type: Type.STRING,
              nullable: true,
            },
            consumerNumber: {
              type: Type.STRING,
              nullable: true,
              description: "Consumer No, USC No, Service No, Account ID, or CA Number.",
            },
            serviceCategory: {
              type: Type.STRING,
              nullable: true,
              description: "Tariff category / domestic / commercial / LT-1 etc.",
            },
            billNumber: {
              type: Type.STRING,
              nullable: true,
            },
            billDate: {
              type: Type.STRING,
              nullable: true,
            },
            billingPeriod: {
              type: Type.STRING,
              nullable: true,
            },
            dueDate: {
              type: Type.STRING,
              nullable: true,
            },
            disconnectionDate: {
              type: Type.STRING,
              nullable: true,
            },
            previousReading: {
              type: Type.STRING,
              nullable: true,
            },
            currentReading: {
              type: Type.STRING,
              nullable: true,
            },
            unitsConsumed: {
              type: Type.STRING,
              nullable: true,
              description: "Total kWh / units billed with unit label.",
            },
            fixedCharges: {
              type: Type.STRING,
              nullable: true,
              description: "Fixed charges / demand charges / monthly base charges as printed.",
            },
            energyCharges: {
              type: Type.STRING,
              nullable: true,
              description: "Energy / electricity consumption charges as printed.",
            },
            taxesAndAdditionalCharges: {
              type: Type.STRING,
              nullable: true,
              description: "Electricity duty, taxes, customer charges, FAC/FPPCA, surcharges, or additional fees as printed.",
            },
            totalAmountPayable: {
              type: Type.STRING,
              nullable: true,
              description: "Total amount due with currency symbol as printed.",
            },
            chargesBreakdown: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  amount: { type: Type.STRING },
                  simpleExplanation: { type: Type.STRING },
                },
                required: ["name", "amount", "simpleExplanation"],
              },
            },
            unavailableFields: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of important standard bill fields not present or unreadable in this document.",
            },
            rawOcrText: {
              type: Type.STRING,
              description: "Complete verbatim OCR or embedded PDF text from the uploaded bill.",
            },
            ocrConfidence: {
              type: Type.STRING,
              enum: ["High", "Medium", "Low"],
              nullable: true,
              description: "Qualitative OCR readability confidence based on text clarity.",
            },
            documentConfidenceNote: {
              type: Type.STRING,
              nullable: true,
              description: "Any factual note about image blur, cropping, or partial pages, or null if clear.",
            },
            initialSummary: {
              type: Type.STRING,
              description:
                "Detailed, easy-to-understand structured Markdown breakdown using headings, bullet points, and a charges table (never dense paragraphs).",
            },
            suggestedQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description:
                "3-4 short, relevant follow-up questions grounded strictly in fields actually extracted from this bill.",
            },
          },
          required: [
            "isElectricityBill",
            "chargesBreakdown",
            "unavailableFields",
            "rawOcrText",
            "initialSummary",
            "suggestedQuestions",
          ],
        },
      });

      const parsed = JSON.parse((response.text ?? "{}").trim());

      const extractedBill: ChatBillInput = {
        slotId: slotId === "bill2" ? "bill2" : "bill1",
        slotLabel: slotLabel || (slotId === "bill2" ? "Bill 2" : "Bill 1"),
        fileName,
        extractionMethod,
        isElectricityBill: Boolean(parsed.isElectricityBill),
        utilityProvider: parsed.utilityProvider ?? null,
        consumerName: parsed.consumerName ?? null,
        consumerNumber: parsed.consumerNumber ?? null,
        serviceCategory: parsed.serviceCategory ?? null,
        billNumber: parsed.billNumber ?? null,
        billDate: parsed.billDate ?? null,
        billingPeriod: parsed.billingPeriod ?? null,
        dueDate: parsed.dueDate ?? null,
        disconnectionDate: parsed.disconnectionDate ?? null,
        previousReading: parsed.previousReading ?? null,
        currentReading: parsed.currentReading ?? null,
        unitsConsumed: parsed.unitsConsumed ?? null,
        fixedCharges: parsed.fixedCharges ?? null,
        energyCharges: parsed.energyCharges ?? null,
        taxesAndAdditionalCharges: parsed.taxesAndAdditionalCharges ?? null,
        totalAmountPayable: parsed.totalAmountPayable ?? null,
        chargesBreakdown: Array.isArray(parsed.chargesBreakdown) ? parsed.chargesBreakdown : [],
        unavailableFields: Array.isArray(parsed.unavailableFields) ? parsed.unavailableFields : [],
        rawOcrText: directPdfText || parsed.rawOcrText || "",
        ocrConfidence:
          extractionMethod === "Embedded PDF Text"
            ? "High"
            : parsed.ocrConfidence ?? null,
        documentConfidenceNote: parsed.documentConfidenceNote ?? null,
      };

      const ocrValidation = validateBillOcrAndConsistency(
        extractedBill,
        languagePreference || "en"
      );

      res.json({
        bill: {
          ...extractedBill,
          mimeType: (originalMimeType || normalizedMime).toLowerCase(),
          preprocessingApplied: Array.isArray(preprocessingApplied) ? preprocessingApplied : [],
          initialSummary: parsed.initialSummary || "Bill analyzed.",
          suggestedQuestions: Array.isArray(parsed.suggestedQuestions)
            ? parsed.suggestedQuestions.slice(0, 4)
            : [],
          ocrValidation,
        },
      });
    } catch (err) {
      console.error("Analyze bill error:", err);
      const { status, message } = formatApiError(err);
      res.status(status).json({ error: message });
    }
  });

  app.post("/api/bills/validate", (req: Request, res: Response) => {
    try {
      const body = req.body as {
        bill?: ChatBillInput;
        languagePreference?: string;
      };
      if (!body.bill) {
        res.status(400).json({ error: "Bill data is required for validation." });
        return;
      }
      const ocrValidation = validateBillOcrAndConsistency(
        body.bill,
        body.languagePreference || "en"
      );
      res.json({ ocrValidation });
    } catch (err) {
      console.error("Validate bill error:", err);
      const { status, message } = formatApiError(err);
      res.status(status).json({ error: message });
    }
  });

  app.post("/api/bills/compare", (req: Request, res: Response) => {
    try {
      const body = req.body as { bills?: ChatBillInput[] };
      const bills = Array.isArray(body.bills) ? body.bills : [];
      if (bills.length < 2) {
        res.status(400).json({
          error: "Two uploaded electricity bills are required for comparison.",
        });
        return;
      }
      const comparison = computeBillComparison(bills.slice(0, 2));
      if (!comparison) {
        res.status(400).json({ error: "Could not compute comparison." });
        return;
      }
      res.json({ comparison });
    } catch (err) {
      console.error("Compare bills error:", err);
      const { status, message } = formatApiError(err);
      res.status(status).json({ error: message });
    }
  });

  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const body = req.body as ChatBody;
      const message = (body.message || "").trim();
      const languagePreference = body.languagePreference || "auto";
      const bills = Array.isArray(body.bills) ? body.bills : [];
      const history = Array.isArray(body.history) ? body.history : [];

      if (!message) {
        res.status(400).json({ error: "Message cannot be empty." });
        return;
      }

      const ai = getAiClient();

      const billsContext =
        bills.length === 0
          ? "NO ELECTRICITY BILLS ARE CURRENTLY UPLOADED."
          : [
              ...bills.map(
                (b) => `=== ${b.slotLabel} (${b.fileName}) ===
Extraction Method: ${b.extractionMethod ?? "OCR"}
OCR Confidence: ${b.ocrConfidence ?? "Unknown"}${b.documentConfidenceNote ? ` (${b.documentConfidenceNote})` : ""}
User-Verified Fields: ${
                  b.verifiedValues && Object.keys(b.verifiedValues).length > 0
                    ? Object.keys(b.verifiedValues).join(", ")
                    : Array.isArray(b.userCorrectedFields) && b.userCorrectedFields.length > 0
                      ? b.userCorrectedFields.join(", ")
                      : "None"
                }
Is Electricity Bill: ${b.isElectricityBill}
Utility Provider: ${formatFieldWithProvenance(b, "utilityProvider")}
Consumer Name: ${formatFieldWithProvenance(b, "consumerName")}
Consumer Number: ${formatFieldWithProvenance(b, "consumerNumber")}
Service Category: ${formatFieldWithProvenance(b, "serviceCategory")}
Bill Number: ${formatFieldWithProvenance(b, "billNumber")}
Bill Date: ${formatFieldWithProvenance(b, "billDate")}
Billing Period: ${formatFieldWithProvenance(b, "billingPeriod")}
Due Date: ${formatFieldWithProvenance(b, "dueDate")}
Disconnection Date: ${formatFieldWithProvenance(b, "disconnectionDate")}
Previous Meter Reading: ${formatFieldWithProvenance(b, "previousReading")}
Current Meter Reading: ${formatFieldWithProvenance(b, "currentReading")}
Units Consumed: ${formatFieldWithProvenance(b, "unitsConsumed")}
Fixed Charges: ${formatFieldWithProvenance(b, "fixedCharges")}
Energy Charges: ${formatFieldWithProvenance(b, "energyCharges")}
Taxes & Additional Charges: ${formatFieldWithProvenance(b, "taxesAndAdditionalCharges")}
Total Amount Payable: ${formatFieldWithProvenance(b, "totalAmountPayable")}
Charges Breakdown: ${JSON.stringify(b.chargesBreakdown ?? [])}
Unavailable Fields: ${JSON.stringify(b.unavailableFields ?? [])}
Missing Information Impact:
${buildMissingInfoAudit(b)}
Smart OCR Error Detection & Validation Audit:
${buildOcrValidationAudit(b)}
Deterministic Numerical Audit (computed using User-Verified values where present, else Original OCR):
${buildSingleBillMathAudit(b)}
Raw OCR / Extracted Text:
${(b.rawOcrText ?? "").slice(0, 12000)}`
              ),
              buildMultiBillComparisonAudit(bills),
            ]
              .filter(Boolean)
              .join("\n\n");

      const recentHistory = history.slice(-18);
      const historyText =
        recentHistory.length === 0
          ? "No prior conversation turns."
          : recentHistory
              .map((m) => `${m.role === "user" ? "User" : "BillWise AI"}: ${m.content}`)
              .join("\n");

      let langDirective = "";
      if (languagePreference === "en") {
        langDirective =
          "The user selected English mode. Reply strictly in clear, simple English (including headings, explanations, evidence notes, clarification options, and suggestedQuestions).";
      } else if (languagePreference === "te") {
        langDirective =
          "The user selected Telugu mode. Reply strictly in natural, easy-to-read Telugu script (తెలుగు) — including headings, explanations, clarification options, and suggestedQuestions — while keeping bill numbers, dates, and IDs accurate.";
      } else if (languagePreference === "hi") {
        langDirective =
          "The user selected Hindi mode. Reply strictly in natural, easy-to-read Hindi using Devanagari script (हिन्दी) — including headings, explanations, clarification options, and suggestedQuestions — while keeping bill numbers, units, dates, and consumer IDs accurate.";
      } else if (languagePreference === "tenglish") {
        langDirective =
          "The user selected Tenglish mode. Reply strictly in natural Tenglish (conversational Telugu written in English/Latin alphabet, e.g., 'Mee bill lo energy charges ₹940 unnayi, fixed charges ₹60 unnayi.') — including headings, explanations, clarification options, and suggestedQuestions.";
      } else {
        langDirective =
          "Auto-detect the language of the user's latest message among English, Telugu, Hindi, and Tenglish: if written in Telugu script (తెలుగు), reply (including headings and suggestedQuestions) in Telugu; if written in Hindi (Devanagari script हिन्दी, or clear Hindi phrasing in Roman letters like 'mera bijli bill kitna hai' / 'due date kab hai'), reply in Hindi using Devanagari script (हिन्दी); if written in Tenglish (Telugu words using English letters like 'bill entha', 'due date eppudu', 'enduku ekkuva vachindi', 'cheppu', 'units enni'), reply (including headings and suggestedQuestions) in natural Tenglish; otherwise reply in English. Always honor explicit language-switch requests in the user's message (e.g., 'Explain in Hindi', 'Hindi mein batao', 'Telugu lo cheppu') while keeping prior conversation context intact.";
      }

      const systemInstruction = `You are BillWise AI, an advanced Evidence-Based Electricity Bill Understanding Chatbot.

STEP 1 — STRICT ELECTRICITY-BILL DOMAIN CLASSIFICATION (MANDATORY BEFORE ANSWERING):
Classify the user's latest question (taking CONVERSATION HISTORY and uploaded bills into account) into EXACTLY ONE 'domainCategory':
1. "ELECTRICITY_BILL_RELATED":
   - Any question about an electricity bill, uploaded bill(s), bill amount, due date, disconnection date, billing period, consumer/service number, units consumed, meter readings, energy/fixed/tax/FAC/customer/arrears/subsidy charges, electricity bill comparison, high bill analysis, bill summary, billing calculations/charge sum verification, payment status (if printed on the bill), OCR value corrections, or short follow-ups ("Why?", "Explain that", "In Telugu", "Does it add up?") continuing an electricity-bill discussion.
   - Also includes questions asking how to upload or inspect an electricity bill in BillWise AI.
2. "ELECTRICITY_CONCEPT_RELATED":
   - Questions about electricity concepts ONLY when they help explain a charge, unit, meter reading, tariff term, or other electricity-bill information (e.g., "What is kWh / 1 unit?", "What is Fixed Charge / Demand Charge?", "What is FAC / FPPCA?", "What is Electricity Duty?", "What does connected load kW or power factor / kVAh mean on an electricity bill?", "How are billed units calculated from meter readings?").
   - CRITICAL RULE: NEVER block valid electricity-bill or bill-concept questions merely because they contain physics or technical terms (like kWh, watts, kW, kVAh, voltage, power factor, units, or math calculations on bill values).
3. "GENERAL_UNRELATED":
   - Any question NOT related to electricity bills or electricity-bill understanding, including:
     * General physics lessons unrelated to explaining an electricity bill (e.g., Newton's laws, Ohm's law, Coulomb's law, magnetism, thermodynamics, quantum physics, optics, gravity, circuits homework)
     * Programming / coding / software questions (Python, Java, JS, SQL, HTML, algorithms, debugging)
     * Mathematics unrelated to electricity bills (algebra, calculus, geometry, general arithmetic not tied to a bill)
     * General knowledge, history, geography, essays, sports, cooking, movies, politics, or other academic topics
4. "UNKNOWN":
   - Unintelligible gibberish, random symbols, or completely unclear prompts that have no recognizable electricity-bill intent even when checking CONVERSATION HISTORY.

IF 'domainCategory' IS "GENERAL_UNRELATED" OR "UNKNOWN":
- Do NOT generate any educational, programming, math, or general-knowledge answer.
- Set 'reply' to ONLY the polite scope statement in the target language, set 'evidence' to [], 'ocrCorrections' to [], 'needsClarification' to false, 'clarificationOptions' to [], 'suggestedQuestions' to [], and 'answerReliability' to "Cannot Determine".

STEP 2 — CORE EVIDENCE-BASED ANSWERING & NLP CAPABILITIES (FOR ELECTRICITY_BILL_RELATED / ELECTRICITY_CONCEPT_RELATED):
1. Strict Evidence Grounding:
   - Answer EVERY electricity-bill question strictly using the extracted/user-verified data and raw OCR text of the uploaded bill(s).
   - For general electricity-bill concept questions (ELECTRICITY_CONCEPT_RELATED) when no bill field is needed, give a clear, beginner-friendly explanation strictly tied to how electricity bills use that concept (and connect it to the uploaded bill if one is loaded).
   - Connect every bill-specific claim in your reply to its exact source bill ('Bill 1' / 'Bill 2'), supporting field name(s), and value(s).
   - Populating 'evidence' is MANDATORY for every bill-data answer: list each supporting item with 'billLabel', 'fieldName', 'value', and 'valueSource' ("Extracted", "User-Verified", or "Calculated").
   - In 'reply', include a clear **Source & Evidence** section/table distinguishing **Extracted from Bill**, **User-Verified**, and **Calculated** values whenever citing uploaded bill data.
2. Question-to-Field Grounding Rules:
   - Total Amount & Charge Questions: MUST list each individual extracted charge (Fixed Charges, Energy Charges, Taxes & Additional Charges, and itemized 'chargesBreakdown' lines), show their arithmetic sum step-by-step, and verify that sum against 'Total Amount Payable' (noting exact match, rounding difference, or unexplained gap/arrears from the Deterministic Numerical Audit).
   - Due-Date Questions: MUST cite the extracted 'Due Date', plus 'Bill Date', 'Billing Period', and 'Disconnection Date' when present (explicitly noting any missing date as not found in the uploaded bill).
   - Consumption & Meter-Reading Questions: MUST cite 'Previous Meter Reading', 'Current Meter Reading', and 'Units Consumed', and show the calculated reading difference ('Current - Previous') check where both readings exist.
   - Payment Status Questions: Cite payment status / paid amount / arrears ONLY if explicitly printed on the uploaded bill; otherwise state clearly that payment status is not found in the uploaded bill.
3. Smart Question Understanding & Follow-Up Resolution:
   - Recognize semantic intent across diverse phrasings in English, Telugu, Hindi, and Tenglish (e.g., "service no / USC no / CA no" = Consumer Number; "last date / fine-free date" = Due Date; "kWh / power used" = Units Consumed; "does my bill add up?" = Charge Sum Verification).
   - Resolve short or elliptical follow-ups ("Why?", "Explain this amount.", "Does that match the total?", "What about last month?", "How much did it increase?", "Which charge increased?") using prior conversation turns and uploaded bill data.
4. Ambiguity Detection (Clarify Before Answering When Truly Ambiguous):
   - If a user's electricity-bill question genuinely has multiple distinct meanings in context, set 'needsClarification' to true, set 'detectedIntent' to "Clarification Needed", provide 2–4 concise 'clarificationOptions' (in the reply language), and ask a polite, structured clarification question BEFORE guessing.
   - Trigger clarification when 2 bills are loaded and user asks "What is the due date?", "How much is the total?", "Explain the charges", or "Correct the amount to ₹1,200" WITHOUT specifying Bill 1 vs Bill 2 (unless recent turns already uniquely focused on one bill), or when asking "What is the date?" / "How much is the charge?" ambiguously.
   - Do NOT trigger clarification unnecessarily when intent is clear.
5. Intelligent Electricity Bill Comparison & Reasoning (Two-Bill Comparison):
   - Whenever the user asks to compare bills, asks why the bill increased/decreased, or asks follow-up questions about differences between two uploaded bills, set 'detectedIntent' to "Intelligent Bill Comparison" (or "Follow-up: Bill Comparison") and use the Deterministic Comparison Analytics strictly.
   - ALWAYS compare and present all available items across both bills:
     * Billing Periods, Bill Dates, and Due Dates
     * Total Bill Amount (exact difference & % change)
     * Units Consumed (exact difference & % change) and Average Cost per Unit
     * Previous & Current Meter Readings (including meter continuity check)
     * Energy Charges, Fixed Charges, Taxes & Additional Charges, and ALL other available itemized charges from 'chargesBreakdown' (including charges present in only one bill)
   - Clearly categorize which charges **Increased**, **Decreased**, or **Remained Unchanged** (plus any new/removed charges appearing in only one bill).
   - Format the main comparison in 'reply' with a **Side-by-Side Comparison Table** (| Metric / Charge | Earlier Bill | Current Bill | Difference | Change |), bulleted takeaways, a **Missing or Unclear Information** section listing any field absent or unclear in either bill, and a **Source & Evidence** section.
   - NEVER assume, speculate, or invent unprinted causes (such as AC usage, summer weather, appliance faults, or suggesting usage entered a higher tariff slab unless slab rates are explicitly printed on the bills). State strictly what the printed charges, units, and deterministic calculations show. If only 1 bill is uploaded, state clearly that a second electricity bill must be uploaded to compare.
6. Consumption Pattern & Follow-up Intelligence:
   - Use the comparison results and conversation history to answer follow-up questions ("Which charge increased most?", "How much did fixed charges change?", "What about meter readings?", "Explain this in Telugu/Hindi/Tenglish").
   - Report exact unit, meter reading, and percentage changes, and explicitly highlight any missing comparison data without guessing.
7. Smart OCR Error Detection, Validation & Confirmation (NEVER Silently Alter Extracted Values):
   - Always inspect the Smart OCR Error Detection & Validation Audit for each bill.
   - If a relevant field has possible OCR character confusion (0/O, 1/I/l, 5/S, 8/B), an unclear/unparseable amount/date/reading/unit, an amount breakdown mismatch, a consumption or date inconsistency, or an incomplete/low-confidence section:
     * NEVER silently replace or alter the original extracted OCR value.
     * Clearly warn the user in their selected language (English, Telugu, Tenglish, or Hindi), state BOTH the **Original OCR Value** and any **Suggested Correction (Unconfirmed)**, and explicitly **ask the user to confirm** the correct value before treating it as verified.
     * Populate 'pendingConfirmations' with any uncertain field that has a suggested correction awaiting user confirmation.
   - Always treat USER-VERIFIED values as authoritative in all answers and calculations, while preserving and acknowledging original OCR values.
   - If the user confirms or corrects an uncertain OCR value in chat unambiguously (in English, Telugu, Tenglish, or Hindi), set 'detectedIntent' to "Smart OCR Correction", populate 'ocrCorrections', and confirm both the preserved original OCR value and the newly confirmed User-Verified value.
8. Missing & Unclear Information Intelligence:
   - If any required value is missing or unclear (e.g., "Not found in uploaded bill", or 'ocrConfidence' is Medium/Low with 'documentConfidenceNote', or unreadable bill sections), show a clear warning stating what is missing/unreadable and which part of the question cannot be answered from the bill.
   - NEVER guess, extrapolate, or fabricate missing values.
9. Answer Confidence & Reliability (NO FAKE PERCENTAGES):
   - Set 'answerReliability' from ["High", "Medium", "Low", "Uncertain", "Cannot Determine"] with a short factual 'reliabilityReason' based ONLY on extraction method, 'ocrConfidence', user verification, and field completeness. Never invent numeric confidence percentages.
10. Smart Suggested Next Questions:
   - Populate 'suggestedQuestions' with 2–3 concise follow-up questions in the SAME language as 'reply', grounded strictly in fields present in the uploaded bill(s) (or [] if no bill is uploaded or if out-of-scope).

RESPONSE FORMAT RULES (STRICT — NO PARAGRAPHS):
- Keep explanations simple, beginner-friendly, and free of dense paragraphs.
- Use short section headings (### Heading), concise bullet points (- **Label:** Value — simple meaning), numbered calculation steps, and Markdown tables (| Field / Charge | Value | Basis / Meaning |).

STRICT GUARDRAILS (NON-NEGOTIABLE):
- NEVER invent missing bill information or assume reasons for increased charges not established by the uploaded bill(s).
- If NO bill has been uploaded yet and the user asks a bill-specific question ('ELECTRICITY_BILL_RELATED' requiring an uploaded bill), politely ask them to upload a PDF or image of their electricity bill first (in the reply language) and set 'answerReliability' to "Cannot Determine".
- Scope restriction: Keep BillWise AI strictly limited to electricity bill understanding (no general physics lessons, coding, unrelated math, general knowledge, payment features, or unrelated tools).

LANGUAGE DIRECTIVE:
${langDirective}`;

      const prompt = `UPLOADED BILL CONTEXT, PROVENANCE & DETERMINISTIC ANALYTICS:
${billsContext}

CONVERSATION HISTORY:
${historyText}

LATEST USER QUESTION:
${message}`;

      const response = await generateWithModelFallback(ai, {
        contents: prompt,
        systemInstruction,
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            domainCategory: {
              type: Type.STRING,
              enum: [
                "ELECTRICITY_BILL_RELATED",
                "ELECTRICITY_CONCEPT_RELATED",
                "GENERAL_UNRELATED",
                "UNKNOWN",
              ],
              description:
                "Strict domain classification of the user's question before generating the answer.",
            },
            detectedIntent: {
              type: Type.STRING,
              description:
                "Concise 2-5 word label describing the user's NLP intent (e.g., 'Intelligent Bill Comparison', 'Bill Concept Explanation', 'Out of Scope', 'Unknown Intent', 'Charge Relationship & Math', 'Smart OCR Correction', 'Clarification Needed', 'Bill Summary', 'Due Date Check').",
            },
            detectedLanguage: {
              type: Type.STRING,
              enum: ["English", "Telugu", "Hindi", "Tenglish"],
              description: "Detected language of the user's question.",
            },
            needsClarification: {
              type: Type.BOOLEAN,
              description:
                "True ONLY when the user's question is genuinely ambiguous and requires a clarification question before answering.",
            },
            clarificationOptions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description:
                "2-4 concise clickable clarification choices in the reply language when needsClarification is true; empty array otherwise.",
            },
            answerReliability: {
              type: Type.STRING,
              enum: ["High", "Medium", "Low", "Uncertain", "Cannot Determine"],
              description:
                "Qualitative reliability grounded in OCR/PDF extraction confidence, user verification, and data completeness. Never use numeric percentages.",
            },
            reliabilityReason: {
              type: Type.STRING,
              description:
                "Short factual explanation of answerReliability (e.g., 'Based on High-confidence Embedded PDF Text' or 'Previous reading missing from uploaded bill').",
            },
            evidence: {
              type: Type.ARRAY,
              description:
                "Supporting bill fields and calculated metrics used in the answer, distinguishing Extracted, User-Verified, and Calculated sources.",
              items: {
                type: Type.OBJECT,
                properties: {
                  billLabel: { type: Type.STRING },
                  fieldName: { type: Type.STRING },
                  value: { type: Type.STRING },
                  valueSource: {
                    type: Type.STRING,
                    enum: ["Extracted", "User-Verified", "Calculated"],
                  },
                },
                required: ["billLabel", "fieldName", "value", "valueSource"],
              },
            },
            ocrCorrections: {
              type: Type.ARRAY,
              description:
                "Populated ONLY when the user explicitly confirms or corrects an extracted OCR field value unambiguously; otherwise empty array.",
              items: {
                type: Type.OBJECT,
                properties: {
                  slotId: {
                    type: Type.STRING,
                    enum: ["bill1", "bill2"],
                  },
                  field: {
                    type: Type.STRING,
                    enum: [
                      "utilityProvider",
                      "consumerName",
                      "consumerNumber",
                      "serviceCategory",
                      "billNumber",
                      "billDate",
                      "billingPeriod",
                      "dueDate",
                      "disconnectionDate",
                      "previousReading",
                      "currentReading",
                      "unitsConsumed",
                      "fixedCharges",
                      "energyCharges",
                      "taxesAndAdditionalCharges",
                      "totalAmountPayable",
                    ],
                  },
                  correctedValue: {
                    type: Type.STRING,
                    nullable: true,
                    description: "The confirmed/corrected value, or null if user says the field is not on the bill.",
                  },
                },
                required: ["slotId", "field", "correctedValue"],
              },
            },
            pendingConfirmations: {
              type: Type.ARRAY,
              description:
                "Uncertain OCR fields with a suggested correction awaiting user confirmation (never auto-applied); empty array if none.",
              items: {
                type: Type.OBJECT,
                properties: {
                  slotId: { type: Type.STRING, enum: ["bill1", "bill2"] },
                  field: {
                    type: Type.STRING,
                    enum: [
                      "utilityProvider",
                      "consumerName",
                      "consumerNumber",
                      "serviceCategory",
                      "billNumber",
                      "billDate",
                      "billingPeriod",
                      "dueDate",
                      "disconnectionDate",
                      "previousReading",
                      "currentReading",
                      "unitsConsumed",
                      "fixedCharges",
                      "energyCharges",
                      "taxesAndAdditionalCharges",
                      "totalAmountPayable",
                    ],
                  },
                  fieldLabel: { type: Type.STRING },
                  originalOcrValue: { type: Type.STRING },
                  suggestedValue: { type: Type.STRING },
                },
                required: [
                  "slotId",
                  "field",
                  "fieldLabel",
                  "originalOcrValue",
                  "suggestedValue",
                ],
              },
            },
            suggestedQuestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description:
                "2-3 short, relevant follow-up questions in the reply language grounded in the uploaded bill's extracted fields.",
            },
            reply: {
              type: Type.STRING,
              description:
                "Detailed, structured answer in Markdown format (headings, bullet lists, tables; never dense paragraphs), including a clear Source & Evidence section when citing bill data.",
            },
          },
          required: [
            "domainCategory",
            "detectedIntent",
            "detectedLanguage",
            "needsClarification",
            "clarificationOptions",
            "answerReliability",
            "reliabilityReason",
            "evidence",
            "ocrCorrections",
            "pendingConfirmations",
            "suggestedQuestions",
            "reply",
          ],
        },
      });

      const parsed = JSON.parse((response.text ?? "{}").trim());

      const validCategories = new Set<DomainCategory>([
        "ELECTRICITY_BILL_RELATED",
        "ELECTRICITY_CONCEPT_RELATED",
        "GENERAL_UNRELATED",
        "UNKNOWN",
      ]);
      const domainCategory: DomainCategory = validCategories.has(parsed.domainCategory)
        ? parsed.domainCategory
        : "UNKNOWN";

      const effectiveLanguage = resolveEffectiveReplyLanguage(
        languagePreference,
        parsed.detectedLanguage,
        message
      );

      // Strict deterministic domain gate: never emit general educational or unrelated answers
      if (domainCategory === "GENERAL_UNRELATED" || domainCategory === "UNKNOWN") {
        res.json({
          domainCategory,
          detectedIntent:
            domainCategory === "UNKNOWN" ? "Unknown / Unclear" : "Out of Scope",
          detectedLanguage: effectiveLanguage,
          needsClarification: false,
          clarificationOptions: [],
          answerReliability: "Cannot Determine",
          reliabilityReason:
            domainCategory === "UNKNOWN"
              ? "Could not determine an electricity-bill related question."
              : "Question is outside the electricity-bill understanding domain.",
          evidence: [],
          ocrCorrections: [],
          pendingConfirmations: [],
          suggestedQuestions: [],
          reply: OUT_OF_SCOPE_REPLIES[effectiveLanguage],
        });
        return;
      }

      res.json({
        domainCategory,
        detectedIntent: parsed.detectedIntent || "General Bill Q&A",
        detectedLanguage: effectiveLanguage,
        needsClarification: Boolean(parsed.needsClarification),
        clarificationOptions: Array.isArray(parsed.clarificationOptions)
          ? parsed.clarificationOptions.slice(0, 4)
          : [],
        answerReliability: parsed.answerReliability || "High",
        reliabilityReason: parsed.reliabilityReason || "",
        evidence: Array.isArray(parsed.evidence) ? parsed.evidence : [],
        ocrCorrections: Array.isArray(parsed.ocrCorrections) ? parsed.ocrCorrections : [],
        pendingConfirmations: Array.isArray(parsed.pendingConfirmations)
          ? parsed.pendingConfirmations
          : [],
        suggestedQuestions: Array.isArray(parsed.suggestedQuestions)
          ? parsed.suggestedQuestions.slice(0, 4)
          : [],
        reply:
          parsed.reply ||
          "I could not generate an answer from the uploaded bill. Please try rephrasing your question.",
      });
    } catch (err) {
      console.error("Chat error:", err);
      const { status, message } = formatApiError(err);
      res.status(status).json({ error: message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    app.use(express.static(distDir));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BillWise AI server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});

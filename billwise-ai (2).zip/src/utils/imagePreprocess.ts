export interface PreparedUpload {
  base64Data: string;
  mimeType: string;
  originalMimeType: string;
  preprocessingApplied: string[];
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === "string" ? reader.result : "";
      const commaIdx = result.indexOf(",");
      if (commaIdx === -1) {
        reject(new Error("Failed to read file as base64."));
        return;
      }
      resolve(result.slice(commaIdx + 1));
    };
    reader.onerror = () => reject(new Error("Could not read selected file."));
    reader.readAsDataURL(file);
  });
}

function loadImageElement(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Unable to decode image for OCR preprocessing."));
    };
    img.src = url;
  });
}

export async function prepareFileForUpload(
  file: File,
  enhanceForOcr: boolean
): Promise<PreparedUpload> {
  const originalMimeType = file.type || "application/octet-stream";

  if (originalMimeType === "application/pdf" || !enhanceForOcr || !originalMimeType.startsWith("image/")) {
    const base64Data = await fileToBase64(file);
    return {
      base64Data,
      mimeType: originalMimeType,
      originalMimeType,
      preprocessingApplied: [],
    };
  }

  try {
    const img = await loadImageElement(file);
    const maxDim = 2200;
    const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
    const width = Math.max(1, Math.round(img.width * scale));
    const height = Math.max(1, Math.round(img.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      const base64Data = await fileToBase64(file);
      return {
        base64Data,
        mimeType: originalMimeType,
        originalMimeType,
        preprocessingApplied: [],
      };
    }

    ctx.filter = "grayscale(100%) contrast(135%) brightness(105%)";
    ctx.drawImage(img, 0, 0, width, height);

    const dataUrl = canvas.toDataURL("image/jpeg", 0.92);
    const commaIdx = dataUrl.indexOf(",");
    const base64Data = commaIdx >= 0 ? dataUrl.slice(commaIdx + 1) : dataUrl;

    const applied = ["grayscale", "contrast-boost"];
    if (scale < 1) applied.push("downscale-2200px");

    return {
      base64Data,
      mimeType: "image/jpeg",
      originalMimeType,
      preprocessingApplied: applied,
    };
  } catch {
    const base64Data = await fileToBase64(file);
    return {
      base64Data,
      mimeType: originalMimeType,
      originalMimeType,
      preprocessingApplied: [],
    };
  }
}

export type LanguagePreference = "auto" | "en" | "te" | "hi" | "tenglish";

export type BillSlotId = "bill1" | "bill2";

export type EditableBillFieldKey =
  | "utilityProvider"
  | "consumerName"
  | "consumerNumber"
  | "serviceCategory"
  | "billNumber"
  | "billDate"
  | "billingPeriod"
  | "dueDate"
  | "disconnectionDate"
  | "previousReading"
  | "currentReading"
  | "unitsConsumed"
  | "fixedCharges"
  | "energyCharges"
  | "taxesAndAdditionalCharges"
  | "totalAmountPayable";

export interface ChargeBreakdownItem {
  name: string;
  amount: string;
  simpleExplanation: string;
}

export type OcrValidationCategory =
  | "confusing_characters"
  | "unclear_value"
  | "amount_mismatch"
  | "consumption_inconsistency"
  | "date_inconsistency"
  | "incomplete_section";

export interface OcrValidationIssue {
  id: string;
  severity: "error" | "warning" | "info";
  category: OcrValidationCategory;
  field: EditableBillFieldKey | "chargesBreakdown" | "rawOcrText" | "general";
  fieldLabel: string;
  originalOcrValue: string | null;
  suggestedValue: string | null;
  confusableMatches?: string[];
  message: string;
  needsUserConfirmation: boolean;
}

export interface OcrValidationResult {
  status: "valid" | "needs_review" | "incomplete";
  hasConfusingCharacters: boolean;
  hasUnclearValues: boolean;
  hasAmountMismatch: boolean;
  hasConsumptionInconsistency: boolean;
  hasDateInconsistency: boolean;
  hasIncompleteSections: boolean;
  issues: OcrValidationIssue[];
  incompleteSections: string[];
  summaryNote: string;
}

export interface AnalyzedBill {
  slotId: BillSlotId;
  slotLabel: string;
  fileName: string;
  mimeType: string;
  extractionMethod: string;
  preprocessingApplied: string[];
  isElectricityBill: boolean;
  utilityProvider: string | null;
  consumerName: string | null;
  consumerNumber: string | null;
  serviceCategory: string | null;
  billNumber: string | null;
  billDate: string | null;
  billingPeriod: string | null;
  dueDate: string | null;
  disconnectionDate: string | null;
  previousReading: string | null;
  currentReading: string | null;
  unitsConsumed: string | null;
  fixedCharges: string | null;
  energyCharges: string | null;
  taxesAndAdditionalCharges: string | null;
  totalAmountPayable: string | null;
  chargesBreakdown: ChargeBreakdownItem[];
  unavailableFields: string[];
  rawOcrText: string;
  ocrConfidence: "High" | "Medium" | "Low" | null;
  documentConfidenceNote: string | null;
  initialSummary: string;
  suggestedQuestions: string[];
  verifiedValues?: Partial<Record<EditableBillFieldKey, string | null>>;
  userCorrectedFields?: string[];
  ocrValidation?: OcrValidationResult;
}

export interface EvidenceItem {
  billLabel: string;
  fieldName: string;
  value: string;
  valueSource: "Extracted" | "User-Verified" | "Calculated";
}

export interface OcrCorrectionItem {
  slotId: BillSlotId;
  field: EditableBillFieldKey;
  correctedValue: string | null;
}

export type DomainCategory =
  | "ELECTRICITY_BILL_RELATED"
  | "ELECTRICITY_CONCEPT_RELATED"
  | "GENERAL_UNRELATED"
  | "UNKNOWN";

export interface PendingConfirmationItem {
  slotId: BillSlotId;
  field: EditableBillFieldKey;
  fieldLabel: string;
  originalOcrValue: string;
  suggestedValue: string;
}

export interface ChatResponsePayload {
  domainCategory: DomainCategory;
  detectedIntent: string;
  detectedLanguage: "English" | "Telugu" | "Hindi" | "Tenglish";
  needsClarification: boolean;
  clarificationOptions: string[];
  answerReliability: "High" | "Medium" | "Low" | "Uncertain" | "Cannot Determine";
  reliabilityReason: string;
  evidence: EvidenceItem[];
  ocrCorrections: OcrCorrectionItem[];
  pendingConfirmations?: PendingConfirmationItem[];
  suggestedQuestions: string[];
  reply: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  meta?: Omit<ChatResponsePayload, "reply">;
}

export const BILL_FIELD_LABELS: Record<EditableBillFieldKey, string> = {
  utilityProvider: "Utility Provider",
  consumerName: "Consumer Name",
  consumerNumber: "Consumer / Service No.",
  serviceCategory: "Tariff / Category",
  billNumber: "Bill Number",
  billDate: "Bill Date",
  billingPeriod: "Billing Period",
  dueDate: "Due Date",
  disconnectionDate: "Disconnection Date",
  previousReading: "Previous Reading",
  currentReading: "Current Reading",
  unitsConsumed: "Units Consumed",
  fixedCharges: "Fixed Charges",
  energyCharges: "Energy Charges",
  taxesAndAdditionalCharges: "Taxes & Additional Charges",
  totalAmountPayable: "Total Amount Payable",
};

export const EDITABLE_FIELD_ORDER: EditableBillFieldKey[] = [
  "utilityProvider",
  "consumerName",
  "consumerNumber",
  "serviceCategory",
  "billNumber",
  "billDate",
  "billingPeriod",
  "dueDate",
  "disconnectionDate",
  "previousReading",
  "currentReading",
  "unitsConsumed",
  "fixedCharges",
  "energyCharges",
  "taxesAndAdditionalCharges",
  "totalAmountPayable",
];

export type ComparisonTrend =
  | "increased"
  | "decreased"
  | "unchanged"
  | "only_in_older"
  | "only_in_newer"
  | "unavailable"
  | "info";

export interface ComparisonRow {
  key: string;
  label: string;
  category: "overview" | "meter" | "charges" | "itemized";
  olderDisplay: string | null;
  newerDisplay: string | null;
  olderNumeric: number | null;
  newerNumeric: number | null;
  difference: number | null;
  percentChange: number | null;
  trend: ComparisonTrend;
  note?: string;
}

export interface BillComparisonResult {
  olderSlotId: BillSlotId;
  olderLabel: string;
  olderFileName: string;
  newerSlotId: BillSlotId;
  newerLabel: string;
  newerFileName: string;
  chronologyNote: string;
  meterContinuityNote: string | null;
  rows: ComparisonRow[];
  increasedCharges: ComparisonRow[];
  decreasedCharges: ComparisonRow[];
  unchangedCharges: ComparisonRow[];
  onlyInOlderCharges: ComparisonRow[];
  onlyInNewerCharges: ComparisonRow[];
  missingOrUnclearFields: Array<{
    billLabel: string;
    fieldLabel: string;
    reason: string;
  }>;
  clarityWarnings: string[];
  avgCostPerUnit: {
    older: number | null;
    newer: number | null;
    difference: number | null;
    percentChange: number | null;
    trend: ComparisonTrend;
  };
  chargeContributions: Array<{
    label: string;
    difference: number;
    shareOfTotalChangePct: number;
  }>;
}

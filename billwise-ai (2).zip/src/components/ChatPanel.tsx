import React, { useEffect, useRef, useState } from "react";
import {
  Check,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Languages,
  Loader2,
  Send,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Trash2,
} from "lucide-react";
import {
  AnalyzedBill,
  BillSlotId,
  ChatMessage,
  EditableBillFieldKey,
  LanguagePreference,
} from "../types";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ChatPanelProps {
  messages: ChatMessage[];
  sending: boolean;
  languagePreference: LanguagePreference;
  onChangeLanguage: (lang: LanguagePreference) => void;
  onSendMessage: (text: string) => void;
  onConfirmPendingValue: (
    slot: BillSlotId,
    field: EditableBillFieldKey,
    value: string | null
  ) => void;
  onClearChat: () => void;
  uploadedBills: AnalyzedBill[];
}

const LANGUAGE_OPTIONS: Array<{ id: LanguagePreference; label: string }> = [
  { id: "auto", label: "Auto" },
  { id: "en", label: "English" },
  { id: "te", label: "తెలుగు" },
  { id: "hi", label: "हिन्दी" },
  { id: "tenglish", label: "Tenglish" },
];

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  sending,
  languagePreference,
  onChangeLanguage,
  onSendMessage,
  onConfirmPendingValue,
  onClearChat,
  uploadedBills,
}) => {
  const [input, setInput] = useState("");
  const [expandedEvidence, setExpandedEvidence] = useState<Record<string, boolean>>({});
  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || sending) return;
    onSendMessage(trimmed);
    setInput("");
  };

  const toggleEvidence = (msgId: string) => {
    setExpandedEvidence((prev) => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  const reliabilityBadgeClass = (rel: string) => {
    if (rel === "High") return "bg-emerald-50 text-emerald-700 border-emerald-200";
    if (rel === "Medium") return "bg-amber-50 text-amber-700 border-amber-200";
    return "bg-rose-50 text-rose-700 border-rose-200";
  };

  const starterPrompts =
    uploadedBills.length >= 2
      ? [
          "Compare both electricity bills with all charges, units, and meter readings.",
          "Which charges increased, decreased, or stayed unchanged?",
          "Rendu bills compare chesi difference Tenglish lo cheppu.",
          "दोनों बिजली बिल की तुलना हिंदी में समझाओ।",
        ]
      : uploadedBills.length === 1
        ? [
            "Explain every charge in simple terms and verify if they add up.",
            "When is the due date and disconnection date?",
            "Mee bill lo units enni, total entha undi?",
            "मेरा बिजली बिल कितना है और आखिरी तारीख कब है?",
          ]
        : [
            "What does 1 unit (kWh) mean on an electricity bill?",
            "What is the difference between fixed charges and energy charges?",
          ];

  return (
    <section className="flex h-full flex-col rounded-2xl border border-slate-200/90 bg-white shadow-sm overflow-hidden">
      {/* Chat Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-slate-50/70 px-4 py-3">
        <div>
          <h2 className="text-sm font-bold text-slate-900">
            Evidence-Based Bill Q&A
          </h2>
          <p className="text-[11px] text-slate-500">
            {uploadedBills.length === 0
              ? "Upload a bill on the left to ask grounded questions"
              : `${uploadedBills.length} bill${uploadedBills.length > 1 ? "s" : ""} loaded (${uploadedBills
                  .map((b) => b.slotLabel)
                  .join(" + ")})`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-0.5">
            <Languages className="ml-1.5 h-3.5 w-3.5 text-slate-400" />
            {LANGUAGE_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChangeLanguage(opt.id)}
                className={`rounded-md px-2 py-1 text-[11px] font-semibold transition-colors ${
                  languagePreference === opt.id
                    ? "bg-slate-900 text-white"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {messages.length > 0 && (
            <button
              type="button"
              onClick={onClearChat}
              title="Clear conversation"
              className="rounded-lg border border-slate-200 bg-white p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center py-8 text-center">
            <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 border border-amber-200 text-amber-600">
              <Sparkles className="h-5 w-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              Ask Anything About Your Electricity Bill
            </h3>
            <p className="mt-1 max-w-md text-xs text-slate-500">
              Ask in English, Telugu (తెలుగు), Hindi (हिन्दी), or Tenglish. Every answer is grounded strictly in your uploaded bill fields and arithmetic checks.
            </p>
            <div className="mt-5 flex max-w-lg flex-wrap justify-center gap-2">
              {starterPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => onSendMessage(prompt)}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 shadow-2xs transition-colors hover:border-amber-300 hover:bg-amber-50/50 hover:text-slate-900"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg, idx) => {
            const isLastAssistant =
              msg.role === "assistant" && idx === messages.length - 1;
            const showEv = Boolean(expandedEvidence[msg.id]);

            if (msg.role === "user") {
              return (
                <div key={msg.id} className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-slate-900 px-4 py-2.5 text-[13.5px] leading-relaxed text-white shadow-xs">
                    {msg.content}
                  </div>
                </div>
              );
            }

            return (
              <div key={msg.id} className="flex flex-col items-start space-y-2">
                <div className="w-full max-w-[95%] rounded-2xl rounded-bl-sm border border-slate-200 bg-white p-4 shadow-2xs">
                  {/* Metadata Badges */}
                  {msg.meta && (
                    <div className="mb-2.5 flex flex-wrap items-center gap-1.5 border-b border-slate-100 pb-2">
                      {msg.meta.domainCategory && (
                        <span
                          className={`rounded-md px-2 py-0.5 text-[10px] font-semibold ${
                            msg.meta.domainCategory === "GENERAL_UNRELATED" ||
                            msg.meta.domainCategory === "UNKNOWN"
                              ? "bg-amber-50 text-amber-800 border border-amber-200"
                              : "bg-slate-900 text-white"
                          }`}
                        >
                          {msg.meta.domainCategory}
                        </span>
                      )}
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-700">
                        {msg.meta.detectedIntent}
                      </span>
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600">
                        {msg.meta.detectedLanguage}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-semibold ${reliabilityBadgeClass(
                          msg.meta.answerReliability
                        )}`}
                        title={msg.meta.reliabilityReason}
                      >
                        <ShieldCheck className="h-3 w-3" />
                        Reliability: {msg.meta.answerReliability}
                      </span>
                      {msg.meta.reliabilityReason && (
                        <span className="text-[11px] text-slate-500">
                          {msg.meta.reliabilityReason}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Main Markdown Reply */}
                  <MarkdownRenderer content={msg.content} />

                  {/* Pending OCR Value Confirmations */}
                  {msg.meta?.pendingConfirmations &&
                    msg.meta.pendingConfirmations.length > 0 && (
                      <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50/70 p-3 space-y-2">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-900">
                          <ShieldAlert className="h-4 w-4 text-amber-600" />
                          <span>Confirm Uncertain OCR Value(s):</span>
                        </div>
                        <div className="space-y-2">
                          {msg.meta.pendingConfirmations.map((pc, pIdx) => {
                            const targetBill = uploadedBills.find(
                              (b) => b.slotId === pc.slotId
                            );
                            const verifiedVal =
                              targetBill?.verifiedValues &&
                              Object.prototype.hasOwnProperty.call(
                                targetBill.verifiedValues,
                                pc.field
                              )
                                ? targetBill.verifiedValues[pc.field]
                                : undefined;
                            const isResolved = verifiedVal !== undefined;

                            return (
                              <div
                                key={`${pc.slotId}-${pc.field}-${pIdx}`}
                                className="rounded-lg border border-amber-200/90 bg-white p-2.5 text-xs"
                              >
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="font-semibold text-slate-900">
                                    {targetBill?.slotLabel || pc.slotId} · {pc.fieldLabel}
                                  </span>
                                  {isResolved && (
                                    <span className="inline-flex items-center gap-1 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-700">
                                      <Check className="h-3 w-3" />
                                      Confirmed: {verifiedVal ?? "Unavailable"}
                                    </span>
                                  )}
                                </div>
                                <div className="mt-1 flex flex-wrap gap-2 text-[11px]">
                                  <span className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 font-mono text-slate-700">
                                    Original OCR: {pc.originalOcrValue}
                                  </span>
                                  <span className="rounded border border-emerald-200 bg-emerald-50 px-2 py-0.5 font-mono text-emerald-800">
                                    Suggested: {pc.suggestedValue}
                                  </span>
                                </div>
                                {!isResolved && (
                                  <div className="mt-2 flex flex-wrap gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onConfirmPendingValue(
                                          pc.slotId,
                                          pc.field,
                                          pc.suggestedValue
                                        )
                                      }
                                      className="inline-flex items-center gap-1 rounded-md bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-slate-800"
                                    >
                                      <Check className="h-3 w-3" />
                                      Confirm {pc.suggestedValue}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onConfirmPendingValue(
                                          pc.slotId,
                                          pc.field,
                                          pc.originalOcrValue
                                        )
                                      }
                                      className="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50"
                                    >
                                      Keep Original ({pc.originalOcrValue})
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                  {/* Clarification Options */}
                  {msg.meta?.needsClarification &&
                    msg.meta.clarificationOptions.length > 0 && (
                      <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50/70 p-3">
                        <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-amber-900">
                          <HelpCircle className="h-4 w-4 text-amber-600" />
                          <span>Please clarify what you meant:</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.meta.clarificationOptions.map((opt, cIdx) => (
                            <button
                              key={cIdx}
                              type="button"
                              onClick={() => onSendMessage(opt)}
                              className="rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-800 hover:bg-amber-100/70"
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                  {/* Evidence Provenance Drawer */}
                  {msg.meta && msg.meta.evidence.length > 0 && (
                    <div className="mt-3 border-t border-slate-100 pt-2.5">
                      <button
                        type="button"
                        onClick={() => toggleEvidence(msg.id)}
                        className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 hover:text-slate-900"
                      >
                        {showEv ? (
                          <ChevronUp className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronDown className="h-3.5 w-3.5" />
                        )}
                        <span>
                          Supporting Evidence ({msg.meta.evidence.length} field
                          {msg.meta.evidence.length > 1 ? "s" : ""})
                        </span>
                      </button>
                      {showEv && (
                        <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
                          {msg.meta.evidence.map((ev, eIdx) => (
                            <div
                              key={eIdx}
                              className="rounded-lg border border-slate-200 bg-slate-50/70 px-2.5 py-1.5 text-[11px]"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-semibold text-slate-700">
                                  {ev.billLabel} · {ev.fieldName}
                                </span>
                                <span
                                  className={`rounded px-1.5 py-0.5 text-[9px] font-semibold uppercase ${
                                    ev.valueSource === "User-Verified"
                                      ? "bg-emerald-100 text-emerald-800"
                                      : ev.valueSource === "Calculated"
                                        ? "bg-amber-100 text-amber-800"
                                        : "bg-slate-200 text-slate-700"
                                  }`}
                                >
                                  {ev.valueSource}
                                </span>
                              </div>
                              <div className="mt-0.5 font-mono text-slate-900">
                                {ev.value}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Follow-up Suggested Questions */}
                {isLastAssistant &&
                  msg.meta &&
                  msg.meta.suggestedQuestions.length > 0 &&
                  !sending && (
                    <div className="flex flex-wrap gap-1.5 pl-1">
                      {msg.meta.suggestedQuestions.map((q, qIdx) => (
                        <button
                          key={qIdx}
                          type="button"
                          onClick={() => onSendMessage(q)}
                          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:border-amber-300 hover:bg-amber-50/60 hover:text-slate-900"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
              </div>
            );
          })
        )}

        {sending && (
          <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs font-medium text-slate-600 w-fit shadow-2xs">
            <Loader2 className="h-4 w-4 animate-spin text-amber-600" />
            <span>Verifying bill fields & generating response...</span>
          </div>
        )}

        <div ref={scrollEndRef} />
      </div>

      {/* Chat Composer */}
      <form
        onSubmit={handleSubmit}
        className="border-t border-slate-200 bg-white p-3"
      >
        <div className="flex items-center gap-2 rounded-xl border border-slate-300 bg-slate-50/50 px-3 py-1.5 focus-within:border-slate-900 focus-within:bg-white">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              uploadedBills.length > 0
                ? "Ask about charges, due date, units, or compare bills (English / తెలుగు / हिन्दी / Tenglish)..."
                : "Ask a question or upload an electricity bill first..."
            }
            className="w-full bg-transparent py-1.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim() || sending}
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-900 text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-300"
            aria-label="Send message"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </form>
    </section>
  );
};

import React, { useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRightLeft,
  Check,
  Edit3,
  FileText,
  Image as ImageIcon,
  Loader2,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import {
  AnalyzedBill,
  BILL_FIELD_LABELS,
  BillComparisonResult,
  BillSlotId,
  EDITABLE_FIELD_ORDER,
  EditableBillFieldKey,
  LanguagePreference,
  OcrValidationIssue,
} from "../types";
import { ComparisonSummaryView } from "./ComparisonSummaryView";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface BillPanelProps {
  bills: Record<BillSlotId, AnalyzedBill | null>;
  activeSlot: BillSlotId;
  onSelectSlot: (slot: BillSlotId) => void;
  showCompareView: boolean;
  onToggleCompareView: (val: boolean) => void;
  comparison: BillComparisonResult | null;
  comparisonLoading: boolean;
  languagePreference: LanguagePreference;
  onExplainComparisonInChat: () => void;
  analyzingSlot: BillSlotId | null;
  uploadError: string | null;
  enhanceForOcr: boolean;
  onToggleEnhanceForOcr: (val: boolean) => void;
  onUploadFile: (slot: BillSlotId, file: File) => void;
  onRemoveBill: (slot: BillSlotId) => void;
  onVerifyField: (
    slot: BillSlotId,
    field: EditableBillFieldKey,
    value: string | null
  ) => void;
  onRevertField: (slot: BillSlotId, field: EditableBillFieldKey) => void;
  onAskQuestion: (question: string) => void;
}

type InspectorTab = "summary" | "fields" | "raw";

export const BillPanel: React.FC<BillPanelProps> = ({
  bills,
  activeSlot,
  onSelectSlot,
  showCompareView,
  onToggleCompareView,
  comparison,
  comparisonLoading,
  languagePreference,
  onExplainComparisonInChat,
  analyzingSlot,
  uploadError,
  enhanceForOcr,
  onToggleEnhanceForOcr,
  onUploadFile,
  onRemoveBill,
  onVerifyField,
  onRevertField,
  onAskQuestion,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [inspectorTab, setInspectorTab] = useState<InspectorTab>("summary");
  const [editingField, setEditingField] = useState<EditableBillFieldKey | null>(null);
  const [editDraft, setEditDraft] = useState("");

  const activeBill = bills[activeSlot];
  const isAnalyzingActive = analyzingSlot === activeSlot;
  const bothBillsReady = Boolean(bills.bill1 && bills.bill2);

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    onUploadFile(activeSlot, files[0]);
  };

  const getDisplayValue = (bill: AnalyzedBill, key: EditableBillFieldKey): string | null => {
    if (bill.verifiedValues && Object.prototype.hasOwnProperty.call(bill.verifiedValues, key)) {
      return bill.verifiedValues[key] ?? null;
    }
    return bill[key] ?? null;
  };

  const isVerified = (bill: AnalyzedBill, key: EditableBillFieldKey): boolean => {
    return Boolean(
      bill.verifiedValues && Object.prototype.hasOwnProperty.call(bill.verifiedValues, key)
    );
  };

  const startEdit = (bill: AnalyzedBill, key: EditableBillFieldKey) => {
    setEditingField(key);
    setEditDraft(getDisplayValue(bill, key) ?? "");
  };

  const commitEdit = (key: EditableBillFieldKey) => {
    const trimmed = editDraft.trim();
    onVerifyField(activeSlot, key, trimmed.length > 0 ? trimmed : null);
    setEditingField(null);
  };

  const confidenceStyle = (conf: AnalyzedBill["ocrConfidence"]) => {
    if (conf === "High") return "bg-emerald-50 text-emerald-700 border-emerald-200";
    if (conf === "Medium") return "bg-amber-50 text-amber-700 border-amber-200";
    if (conf === "Low") return "bg-rose-50 text-rose-700 border-rose-200";
    return "bg-slate-100 text-slate-600 border-slate-200";
  };

  const isEditableFieldKey = (
    field: OcrValidationIssue["field"]
  ): field is EditableBillFieldKey => {
    return EDITABLE_FIELD_ORDER.includes(field as EditableBillFieldKey);
  };

  return (
    <section className="flex h-full flex-col rounded-2xl border border-slate-200/90 bg-white shadow-sm overflow-hidden">
      {/* Slot Switcher Header */}
      <div className="border-b border-slate-200 bg-slate-50/70 px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 rounded-lg bg-slate-200/70 p-1">
            {(["bill1", "bill2"] as BillSlotId[]).map((slot) => {
              const bill = bills[slot];
              const isSelected = !showCompareView && activeSlot === slot;
              const isBusy = analyzingSlot === slot;
              return (
                <button
                  key={slot}
                  type="button"
                  onClick={() => {
                    onToggleCompareView(false);
                    onSelectSlot(slot);
                    setEditingField(null);
                  }}
                  className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-all ${
                    isSelected
                      ? "bg-white text-slate-900 shadow-xs"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <span>{slot === "bill1" ? "Bill 1" : "Bill 2"}</span>
                  {isBusy ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin text-amber-600" />
                  ) : bill ? (
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  ) : null}
                </button>
              );
            })}
            {bothBillsReady && (
              <button
                type="button"
                onClick={() => {
                  onToggleCompareView(true);
                  setEditingField(null);
                }}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1.5 text-xs font-semibold transition-all ${
                  showCompareView
                    ? "bg-slate-900 text-white shadow-xs"
                    : "text-amber-800 bg-amber-100/80 hover:bg-amber-100"
                }`}
              >
                <ArrowRightLeft className="h-3.5 w-3.5" />
                <span>Compare</span>
              </button>
            )}
          </div>

          <label className="flex cursor-pointer items-center gap-1.5 text-[11px] font-medium text-slate-600 select-none">
            <input
              type="checkbox"
              checked={enhanceForOcr}
              onChange={(e) => onToggleEnhanceForOcr(e.target.checked)}
              className="h-3.5 w-3.5 rounded border-slate-300 accent-slate-900"
            />
            <span>Enhance photo OCR</span>
          </label>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4">
        <input
          ref={fileInputRef}
          type="file"
          accept="application/pdf,image/png,image/jpeg,image/webp"
          className="hidden"
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = "";
          }}
        />

        {uploadError && (
          <div className="mb-3 flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2.5 text-xs text-rose-800">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
            <span>{uploadError}</span>
          </div>
        )}

        {showCompareView && bothBillsReady ? (
          <ComparisonSummaryView
            comparison={comparison}
            loading={comparisonLoading}
            languagePreference={languagePreference}
            onExplainInChat={onExplainComparisonInChat}
          />
        ) : isAnalyzingActive ? (
          <div className="flex h-64 flex-col items-center justify-center rounded-xl border border-dashed border-amber-300 bg-amber-50/40 p-6 text-center">
            <Loader2 className="mb-3 h-8 w-8 animate-spin text-amber-600" />
            <p className="text-sm font-semibold text-slate-900">
              Extracting text & analyzing {activeSlot === "bill1" ? "Bill 1" : "Bill 2"}...
            </p>
            <p className="mt-1 max-w-xs text-xs text-slate-600">
              Running PDF text / OCR extraction and structuring meter readings, tariffs, and charges.
            </p>
          </div>
        ) : !activeBill ? (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFiles(e.dataTransfer.files);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`flex min-h-[260px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-6 text-center transition-colors ${
              dragOver
                ? "border-amber-500 bg-amber-50/60"
                : "border-slate-300 bg-slate-50/60 hover:border-slate-400 hover:bg-slate-50"
            }`}
          >
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white shadow-xs border border-slate-200 text-slate-700">
              <Upload className="h-5 w-5" />
            </div>
            <p className="text-sm font-semibold text-slate-900">
              Upload {activeSlot === "bill1" ? "Primary Electricity Bill" : "Second Bill to Compare"}
            </p>
            <p className="mt-1 max-w-xs text-xs text-slate-500">
              Drag and drop a PDF, PNG, JPG, or WEBP electricity bill here, or click to browse.
            </p>
            <div className="mt-4 flex items-center gap-3 text-[11px] font-medium text-slate-500">
              <span className="inline-flex items-center gap-1">
                <FileText className="h-3.5 w-3.5" /> Digital & Scanned PDF
              </span>
              <span className="inline-flex items-center gap-1">
                <ImageIcon className="h-3.5 w-3.5" /> Photo / Thermal Slip
              </span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Uploaded File Metadata Banner */}
            <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="truncate text-xs font-semibold text-slate-900">
                      {activeBill.fileName}
                    </span>
                    <span className="rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] font-medium text-slate-600">
                      {activeBill.extractionMethod}
                    </span>
                    {activeBill.ocrConfidence && (
                      <span
                        className={`rounded-md border px-1.5 py-0.5 text-[10px] font-semibold ${confidenceStyle(
                          activeBill.ocrConfidence
                        )}`}
                      >
                        OCR: {activeBill.ocrConfidence}
                      </span>
                    )}
                  </div>
                  {activeBill.documentConfidenceNote && (
                    <p className="mt-1 text-[11px] text-amber-700">
                      {activeBill.documentConfidenceNote}
                    </p>
                  )}
                </div>

                <div className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    title="Replace bill"
                    className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100"
                  >
                    Replace
                  </button>
                  <button
                    type="button"
                    onClick={() => onRemoveBill(activeSlot)}
                    title="Remove bill"
                    className="rounded-lg border border-slate-200 bg-white p-1.5 text-slate-500 hover:border-rose-200 hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {!activeBill.isElectricityBill && (
                <div className="mt-2.5 flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 px-2.5 py-2 text-xs text-amber-900">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                  <span>
                    This file may not be an electricity utility bill. Extracted fields might be incomplete.
                  </span>
                </div>
              )}
            </div>

            {/* Smart OCR Error Detection & Validation Panel */}
            {activeBill.ocrValidation && (
              activeBill.ocrValidation.issues.length === 0 ? (
                <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-xs text-emerald-800">
                  <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600" />
                  <span>{activeBill.ocrValidation.summaryNote}</span>
                </div>
              ) : (
                <div
                  className={`rounded-xl border p-3 space-y-2.5 ${
                    activeBill.ocrValidation.issues.some((i) => i.severity === "error")
                      ? "border-rose-200 bg-rose-50/60"
                      : "border-amber-200 bg-amber-50/70"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2">
                      <ShieldAlert
                        className={`mt-0.5 h-4 w-4 shrink-0 ${
                          activeBill.ocrValidation.issues.some((i) => i.severity === "error")
                            ? "text-rose-600"
                            : "text-amber-600"
                        }`}
                      />
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-900">
                            Smart OCR Validation
                          </span>
                          <span
                            className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${
                              activeBill.ocrValidation.status === "incomplete"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-rose-100 text-rose-800"
                            }`}
                          >
                            {activeBill.ocrValidation.status === "incomplete"
                              ? "Incomplete Sections"
                              : "Needs Review"}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[11px] text-slate-700">
                          {activeBill.ocrValidation.summaryNote}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {activeBill.ocrValidation.issues.map((issue) => {
                      const canEditField = isEditableFieldKey(issue.field);
                      return (
                        <div
                          key={issue.id}
                          className="rounded-lg border border-slate-200/90 bg-white p-2.5 text-xs shadow-2xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold text-slate-900">
                              {issue.fieldLabel}
                            </span>
                            <span
                              className={`rounded px-1.5 py-0.5 text-[9px] font-semibold uppercase ${
                                issue.severity === "error"
                                  ? "bg-rose-100 text-rose-800"
                                  : issue.severity === "warning"
                                    ? "bg-amber-100 text-amber-800"
                                    : "bg-slate-100 text-slate-700"
                              }`}
                            >
                              {issue.category.replace(/_/g, " ")}
                            </span>
                          </div>
                          <p className="mt-1 text-[11px] leading-relaxed text-slate-600">
                            {issue.message}
                          </p>

                          {(issue.originalOcrValue || issue.suggestedValue) && (
                            <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px]">
                              {issue.originalOcrValue && (
                                <span className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 font-mono text-slate-700">
                                  Original OCR: {issue.originalOcrValue}
                                </span>
                              )}
                              {issue.suggestedValue && (
                                <span className="rounded border border-emerald-200 bg-emerald-50 px-2 py-0.5 font-mono text-emerald-800">
                                  Suggested: {issue.suggestedValue}
                                </span>
                              )}
                            </div>
                          )}

                          {canEditField && issue.needsUserConfirmation && (
                            <div className="mt-2 flex flex-wrap items-center gap-1.5">
                              {issue.suggestedValue && (
                                <button
                                  type="button"
                                  onClick={() =>
                                    onVerifyField(
                                      activeSlot,
                                      issue.field as EditableBillFieldKey,
                                      issue.suggestedValue
                                    )
                                  }
                                  className="inline-flex items-center gap-1 rounded-md bg-slate-900 px-2 py-1 text-[11px] font-semibold text-white hover:bg-slate-800"
                                >
                                  <Check className="h-3 w-3" />
                                  Confirm Suggested
                                </button>
                              )}
                              {issue.originalOcrValue &&
                                (issue.category === "confusing_characters" ||
                                  issue.category === "unclear_value") && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onVerifyField(
                                        activeSlot,
                                        issue.field as EditableBillFieldKey,
                                        issue.originalOcrValue
                                      )
                                    }
                                    className="rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50"
                                  >
                                    Keep Original
                                  </button>
                                )}
                              <button
                                type="button"
                                onClick={() => {
                                  setInspectorTab("fields");
                                  startEdit(
                                    activeBill,
                                    issue.field as EditableBillFieldKey
                                  );
                                }}
                                className="rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50"
                              >
                                Edit Manually
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )
            )}

            {/* Key Quick Metrics Strip */}
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-xl border border-slate-200 bg-white p-2.5">
                <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
                  Total Payable
                </div>
                <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
                  {getDisplayValue(activeBill, "totalAmountPayable") ?? "—"}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 bg-white p-2.5">
                <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
                  Units Used
                </div>
                <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
                  {getDisplayValue(activeBill, "unitsConsumed") ?? "—"}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 bg-white p-2.5">
                <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
                  Due Date
                </div>
                <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
                  {getDisplayValue(activeBill, "dueDate") ?? "—"}
                </div>
              </div>
            </div>

            {/* Inspector Sub-tabs */}
            <div className="flex border-b border-slate-200 text-xs font-semibold">
              {(
                [
                  { id: "summary", label: "Bill Summary" },
                  { id: "fields", label: "Extracted & Verified Fields" },
                  { id: "raw", label: "Charges & Raw OCR" },
                ] as { id: InspectorTab; label: string }[]
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setInspectorTab(tab.id)}
                  className={`border-b-2 px-3 py-2 transition-colors ${
                    inspectorTab === tab.id
                      ? "border-slate-900 text-slate-900"
                      : "border-transparent text-slate-500 hover:text-slate-800"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab 1: Initial Markdown Summary */}
            {inspectorTab === "summary" && (
              <div className="space-y-3">
                <div className="rounded-xl border border-slate-200/80 bg-slate-50/40 p-3.5">
                  <MarkdownRenderer content={activeBill.initialSummary} />
                </div>

                {activeBill.suggestedQuestions.length > 0 && (
                  <div>
                    <div className="mb-1.5 flex items-center gap-1 text-[11px] font-semibold text-slate-600">
                      <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                      <span>Ask about this bill</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {activeBill.suggestedQuestions.map((q, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => onAskQuestion(q)}
                          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-left text-xs font-medium text-slate-700 transition-colors hover:border-amber-300 hover:bg-amber-50/60 hover:text-slate-900"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Structured Fields + Inline Verification/Editing */}
            {inspectorTab === "fields" && (
              <div className="space-y-2">
                <p className="text-[11px] text-slate-500">
                  Review extracted fields below. Click edit on any field to correct an OCR typo — verified values are immediately used in all Q&A calculations.
                </p>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white">
                  {EDITABLE_FIELD_ORDER.map((fieldKey) => {
                    const value = getDisplayValue(activeBill, fieldKey);
                    const verified = isVerified(activeBill, fieldKey);
                    const isEditing = editingField === fieldKey;
                    const fieldIssue = activeBill.ocrValidation?.issues.find(
                      (i) => i.field === fieldKey && i.needsUserConfirmation
                    );

                    return (
                      <div
                        key={fieldKey}
                        className="flex items-center justify-between gap-2 px-3 py-2 text-xs"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="font-medium text-slate-500">
                              {BILL_FIELD_LABELS[fieldKey]}
                            </span>
                            {verified && (
                              <span className="rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-700">
                                User-Verified
                              </span>
                            )}
                            {fieldIssue && (
                              <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">
                                Check OCR{fieldIssue.suggestedValue ? ` (Suggested: ${fieldIssue.suggestedValue})` : ""}
                              </span>
                            )}
                          </div>
                          {isEditing ? (
                            <div className="mt-1 flex items-center gap-1.5">
                              <input
                                type="text"
                                value={editDraft}
                                onChange={(e) => setEditDraft(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") commitEdit(fieldKey);
                                  if (e.key === "Escape") setEditingField(null);
                                }}
                                placeholder="Leave empty if not on bill"
                                className="w-full rounded-md border border-slate-300 px-2 py-1 text-xs text-slate-900 focus:border-slate-900 focus:outline-none"
                                autoFocus
                              />
                              <button
                                type="button"
                                onClick={() => commitEdit(fieldKey)}
                                className="rounded-md bg-slate-900 p-1 text-white hover:bg-slate-800"
                                title="Save"
                              >
                                <Check className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingField(null)}
                                className="rounded-md border border-slate-200 p-1 text-slate-500 hover:bg-slate-100"
                                title="Cancel"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div
                              className={`mt-0.5 font-medium ${
                                value ? "text-slate-900" : "italic text-slate-400"
                              }`}
                            >
                              {value ?? "Not found in uploaded bill"}
                              {verified &&
                                activeBill[fieldKey] &&
                                activeBill[fieldKey] !== value && (
                                  <span className="ml-2 text-[10px] font-normal text-slate-400">
                                    (Original OCR: {activeBill[fieldKey]})
                                  </span>
                                )}
                            </div>
                          )}
                        </div>

                        {!isEditing && (
                          <div className="flex shrink-0 items-center gap-1">
                            {verified && (
                              <button
                                type="button"
                                onClick={() => onRevertField(activeSlot, fieldKey)}
                                title="Revert to original OCR"
                                className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                              >
                                <RotateCcw className="h-3.5 w-3.5" />
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => startEdit(activeBill, fieldKey)}
                              title="Edit / Verify value"
                              className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab 3: Charges Breakdown & Raw OCR */}
            {inspectorTab === "raw" && (
              <div className="space-y-4">
                {activeBill.chargesBreakdown.length > 0 && (
                  <div>
                    <h4 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-slate-600">
                      Itemized Charges
                    </h4>
                    <div className="overflow-hidden rounded-xl border border-slate-200">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 text-slate-600">
                          <tr>
                            <th className="px-3 py-2 font-semibold">Charge</th>
                            <th className="px-3 py-2 font-semibold">Amount</th>
                            <th className="px-3 py-2 font-semibold">Meaning</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {activeBill.chargesBreakdown.map((item, idx) => (
                            <tr key={idx}>
                              <td className="px-3 py-2 font-medium text-slate-900">
                                {item.name}
                              </td>
                              <td className="px-3 py-2 font-mono text-slate-800 whitespace-nowrap">
                                {item.amount}
                              </td>
                              <td className="px-3 py-2 text-slate-600">
                                {item.simpleExplanation}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {activeBill.unavailableFields.length > 0 && (
                  <div>
                    <h4 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-slate-600">
                      Unavailable Fields
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {activeBill.unavailableFields.map((f, idx) => (
                        <span
                          key={idx}
                          className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-600"
                        >
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-slate-600">
                    Raw Extracted / OCR Text
                  </h4>
                  <pre className="max-h-72 overflow-auto rounded-xl border border-slate-200 bg-slate-900 p-3 font-mono text-[11px] leading-relaxed text-slate-100 whitespace-pre-wrap">
                    {activeBill.rawOcrText || "(No raw text available)"}
                  </pre>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

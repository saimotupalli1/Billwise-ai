import React from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowRightLeft,
  ArrowUpRight,
  Minus,
  Sparkles,
} from "lucide-react";
import {
  BillComparisonResult,
  ComparisonRow,
  ComparisonTrend,
  LanguagePreference,
} from "../types";

interface ComparisonSummaryViewProps {
  comparison: BillComparisonResult | null;
  loading: boolean;
  languagePreference: LanguagePreference;
  onExplainInChat: () => void;
}

function formatDiff(row: ComparisonRow): string {
  if (row.trend === "only_in_newer") {
    return row.difference !== null ? `+${row.difference} (New)` : "New";
  }
  if (row.trend === "only_in_older") {
    return row.difference !== null ? `${row.difference} (Removed)` : "Removed";
  }
  if (row.difference === null) return "—";
  const sign = row.difference > 0 ? "+" : "";
  const pct =
    row.percentChange !== null
      ? ` (${row.percentChange > 0 ? "+" : ""}${row.percentChange}%)`
      : "";
  return `${sign}${row.difference}${pct}`;
}

function TrendBadge({ trend }: { trend: ComparisonTrend }) {
  if (trend === "increased") {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 px-1.5 py-0.5 text-[10px] font-semibold text-rose-700 border border-rose-200">
        <ArrowUpRight className="h-3 w-3" />
        Increased
      </span>
    );
  }
  if (trend === "decreased") {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-md bg-emerald-50 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-700 border border-emerald-200">
        <ArrowDownRight className="h-3 w-3" />
        Decreased
      </span>
    );
  }
  if (trend === "unchanged") {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-700 border border-slate-200">
        <Minus className="h-3 w-3" />
        Unchanged
      </span>
    );
  }
  if (trend === "only_in_newer") {
    return (
      <span className="inline-flex items-center rounded-md bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800 border border-amber-200">
        Added
      </span>
    );
  }
  if (trend === "only_in_older") {
    return (
      <span className="inline-flex items-center rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600 border border-slate-200">
        Not in Current
      </span>
    );
  }
  if (trend === "unavailable") {
    return (
      <span className="inline-flex items-center rounded-md bg-slate-50 px-1.5 py-0.5 text-[10px] font-medium text-slate-500 border border-slate-200">
        Missing/Unclear
      </span>
    );
  }
  return (
    <span className="inline-flex items-center rounded-md bg-slate-50 px-1.5 py-0.5 text-[10px] font-medium text-slate-600 border border-slate-200">
      Info
    </span>
  );
}

export const ComparisonSummaryView: React.FC<ComparisonSummaryViewProps> = ({
  comparison,
  loading,
  languagePreference,
  onExplainInChat,
}) => {
  if (loading || !comparison) {
    return (
      <div className="flex h-60 flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50/50 p-6 text-center">
        <ArrowRightLeft className="mb-2 h-6 w-6 text-slate-400" />
        <p className="text-xs font-medium text-slate-600">
          {loading
            ? "Computing deterministic bill comparison..."
            : "Upload both Bill 1 and Bill 2 to view comparison analytics."}
        </p>
      </div>
    );
  }

  const totalRow = comparison.rows.find((r) => r.key === "totalAmountPayable");
  const unitsRow = comparison.rows.find((r) => r.key === "unitsConsumed");

  const explainButtonLabel = (() => {
    switch (languagePreference) {
      case "te":
        return "Explain Comparison in Telugu (తెలుగు)";
      case "hi":
        return "Explain Comparison in Hindi (हिन्दी)";
      case "tenglish":
        return "Explain Comparison in Tenglish";
      case "en":
        return "Explain Comparison in English";
      default:
        return "Ask Chatbot to Explain Comparison";
    }
  })();

  return (
    <div className="space-y-4">
      {/* Chronology & Continuity Banner */}
      <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-900">
            {comparison.olderLabel} (Earlier) → {comparison.newerLabel} (Current)
          </span>
          <button
            type="button"
            onClick={onExplainInChat}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-slate-800 transition-colors"
          >
            <Sparkles className="h-3.5 w-3.5 text-amber-400" />
            <span>{explainButtonLabel}</span>
          </button>
        </div>
        <p className="text-[11px] text-slate-600">{comparison.chronologyNote}</p>
        {comparison.meterContinuityNote && (
          <p className="text-[11px] text-slate-700 font-medium">
            {comparison.meterContinuityNote}
          </p>
        )}
      </div>

      {/* Headline Delta Strip */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl border border-slate-200 bg-white p-2.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
            Total Diff
          </div>
          <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
            {totalRow ? formatDiff(totalRow) : "—"}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-2.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
            Units Diff
          </div>
          <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
            {unitsRow ? formatDiff(unitsRow) : "—"}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-2.5">
          <div className="text-[10px] font-medium uppercase tracking-wider text-slate-500">
            Avg Cost / Unit
          </div>
          <div className="mt-0.5 truncate text-sm font-bold text-slate-900">
            {comparison.avgCostPerUnit.difference !== null
              ? `${comparison.avgCostPerUnit.difference > 0 ? "+" : ""}${comparison.avgCostPerUnit.difference}/u`
              : "—"}
          </div>
        </div>
      </div>

      {/* Charge Movement Summary Chips */}
      <div className="rounded-xl border border-slate-200 bg-white p-3 space-y-2 text-xs">
        <div className="font-bold text-slate-800">Charge Movement Summary</div>
        <div className="grid gap-1.5 text-[11px]">
          <div>
            <span className="font-semibold text-rose-700">Increased: </span>
            <span className="text-slate-700">
              {comparison.increasedCharges.length > 0
                ? comparison.increasedCharges.map((r) => `${r.label} (${formatDiff(r)})`).join(", ")
                : "None"}
            </span>
          </div>
          <div>
            <span className="font-semibold text-emerald-700">Decreased: </span>
            <span className="text-slate-700">
              {comparison.decreasedCharges.length > 0
                ? comparison.decreasedCharges.map((r) => `${r.label} (${formatDiff(r)})`).join(", ")
                : "None"}
            </span>
          </div>
          <div>
            <span className="font-semibold text-slate-600">Unchanged: </span>
            <span className="text-slate-700">
              {comparison.unchangedCharges.length > 0
                ? comparison.unchangedCharges.map((r) => r.label).join(", ")
                : "None"}
            </span>
          </div>
          {(comparison.onlyInNewerCharges.length > 0 ||
            comparison.onlyInOlderCharges.length > 0) && (
            <div>
              <span className="font-semibold text-amber-700">Bill-Specific Charges: </span>
              <span className="text-slate-700">
                {[
                  ...comparison.onlyInNewerCharges.map(
                    (r) => `${r.label} (only in ${comparison.newerLabel}: ${r.newerDisplay})`
                  ),
                  ...comparison.onlyInOlderCharges.map(
                    (r) => `${r.label} (only in ${comparison.olderLabel}: ${r.olderDisplay})`
                  ),
                ].join("; ")}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Side-by-Side Comparison Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="min-w-full border-collapse text-left text-xs">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="border-b border-slate-200 px-3 py-2 font-semibold">
                Field / Charge
              </th>
              <th className="border-b border-slate-200 px-3 py-2 font-semibold">
                {comparison.olderLabel}
              </th>
              <th className="border-b border-slate-200 px-3 py-2 font-semibold">
                {comparison.newerLabel}
              </th>
              <th className="border-b border-slate-200 px-3 py-2 font-semibold">
                Difference
              </th>
              <th className="border-b border-slate-200 px-3 py-2 font-semibold">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {comparison.rows.map((row) => (
              <tr key={row.key} className="hover:bg-slate-50/70">
                <td className="px-3 py-2 font-medium text-slate-900">
                  {row.label}
                </td>
                <td className="px-3 py-2 font-mono text-[11px] text-slate-700">
                  {row.olderDisplay ?? (
                    <span className="italic text-slate-400">Not found</span>
                  )}
                </td>
                <td className="px-3 py-2 font-mono text-[11px] text-slate-700">
                  {row.newerDisplay ?? (
                    <span className="italic text-slate-400">Not found</span>
                  )}
                </td>
                <td className="px-3 py-2 font-mono text-[11px] text-slate-900 whitespace-nowrap">
                  {formatDiff(row)}
                </td>
                <td className="px-3 py-2 whitespace-nowrap">
                  <TrendBadge trend={row.trend} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Missing / Unclear Fields & Clarity Warnings */}
      {(comparison.missingOrUnclearFields.length > 0 ||
        comparison.clarityWarnings.length > 0) && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs text-amber-950 space-y-1.5">
          <div className="flex items-center gap-1.5 font-semibold text-amber-900">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
            <span>Missing or Unclear Information</span>
          </div>
          <ul className="list-disc pl-5 space-y-0.5 text-[11px] text-amber-900">
            {comparison.clarityWarnings.map((w, idx) => (
              <li key={`cw-${idx}`}>{w}</li>
            ))}
            {comparison.missingOrUnclearFields.map((m, idx) => (
              <li key={`mf-${idx}`}>
                <strong>{m.billLabel}</strong> — {m.fieldLabel}: {m.reason}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

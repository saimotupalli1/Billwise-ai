import React, { useEffect, useState } from "react";
import { Zap } from "lucide-react";
import { BillPanel } from "./components/BillPanel";
import { ChatPanel } from "./components/ChatPanel";
import {
  AnalyzedBill,
  BillComparisonResult,
  BillSlotId,
  ChatMessage,
  ChatResponsePayload,
  EditableBillFieldKey,
  LanguagePreference,
  OcrValidationResult,
} from "./types";
import { prepareFileForUpload } from "./utils/imagePreprocess";

export default function App() {
  const [bills, setBills] = useState<Record<BillSlotId, AnalyzedBill | null>>({
    bill1: null,
    bill2: null,
  });
  const [activeSlot, setActiveSlot] = useState<BillSlotId>("bill1");
  const [analyzingSlot, setAnalyzingSlot] = useState<BillSlotId | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [enhanceForOcr, setEnhanceForOcr] = useState(true);

  const [languagePreference, setLanguagePreference] =
    useState<LanguagePreference>("auto");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [sending, setSending] = useState(false);

  const [showCompareView, setShowCompareView] = useState(false);
  const [comparison, setComparison] = useState<BillComparisonResult | null>(null);
  const [comparisonLoading, setComparisonLoading] = useState(false);

  const uploadedBillsList: AnalyzedBill[] = (["bill1", "bill2"] as BillSlotId[])
    .map((id) => bills[id])
    .filter((b): b is AnalyzedBill => b !== null);

  useEffect(() => {
    if (!bills.bill1 || !bills.bill2) {
      setComparison(null);
      setShowCompareView(false);
      return;
    }

    let cancelled = false;
    setComparisonLoading(true);
    fetch("/api/bills/compare", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bills: [bills.bill1, bills.bill2] }),
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("Compare failed"))))
      .then((data) => {
        if (!cancelled && data.comparison) {
          setComparison(data.comparison as BillComparisonResult);
        }
      })
      .catch(() => {
        if (!cancelled) setComparison(null);
      })
      .finally(() => {
        if (!cancelled) setComparisonLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [bills.bill1, bills.bill2]);

  const revalidateBill = async (
    slot: BillSlotId,
    billToValidate: AnalyzedBill,
    lang: LanguagePreference = languagePreference
  ) => {
    try {
      const res = await fetch("/api/bills/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bill: billToValidate, languagePreference: lang }),
      });
      if (!res.ok) return;
      const data = (await res.json()) as { ocrValidation?: OcrValidationResult };
      if (!data.ocrValidation) return;
      setBills((prev) => {
        const current = prev[slot];
        if (!current || current.fileName !== billToValidate.fileName) return prev;
        return {
          ...prev,
          [slot]: {
            ...current,
            ocrValidation: data.ocrValidation,
          },
        };
      });
    } catch {
      // Keep existing validation state on transient network failure
    }
  };

  useEffect(() => {
    (["bill1", "bill2"] as BillSlotId[]).forEach((slot) => {
      const b = bills[slot];
      if (b) {
        void revalidateBill(slot, b, languagePreference);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [languagePreference]);

  const handleUploadFile = async (slot: BillSlotId, file: File) => {
    setUploadError(null);
    setAnalyzingSlot(slot);
    setActiveSlot(slot);

    try {
      const prepared = await prepareFileForUpload(file, enhanceForOcr);
      const response = await fetch("/api/bills/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: file.name,
          mimeType: prepared.mimeType,
          originalMimeType: prepared.originalMimeType,
          base64Data: prepared.base64Data,
          slotId: slot,
          slotLabel: slot === "bill1" ? "Bill 1" : "Bill 2",
          languagePreference,
          preprocessingApplied: prepared.preprocessingApplied,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to analyze uploaded bill.");
      }

      const analyzed = data.bill as AnalyzedBill;
      setBills((prev) => {
        const next = { ...prev, [slot]: analyzed };
        if (next.bill1 && next.bill2) {
          setShowCompareView(true);
        }
        return next;
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to analyze bill.";
      setUploadError(msg);
    } finally {
      setAnalyzingSlot(null);
    }
  };

  const handleRemoveBill = (slot: BillSlotId) => {
    setBills((prev) => ({ ...prev, [slot]: null }));
    setUploadError(null);
  };

  const handleVerifyField = (
    slot: BillSlotId,
    field: EditableBillFieldKey,
    value: string | null
  ) => {
    setBills((prev) => {
      const target = prev[slot];
      if (!target) return prev;
      const verifiedValues = { ...(target.verifiedValues || {}), [field]: value };
      const correctedSet = new Set(target.userCorrectedFields || []);
      correctedSet.add(field);
      const updatedBill: AnalyzedBill = {
        ...target,
        verifiedValues,
        userCorrectedFields: Array.from(correctedSet),
      };
      void revalidateBill(slot, updatedBill);
      return {
        ...prev,
        [slot]: updatedBill,
      };
    });
  };

  const handleRevertField = (slot: BillSlotId, field: EditableBillFieldKey) => {
    setBills((prev) => {
      const target = prev[slot];
      if (!target) return prev;
      const verifiedValues = { ...(target.verifiedValues || {}) };
      delete verifiedValues[field];
      const userCorrectedFields = (target.userCorrectedFields || []).filter(
        (f) => f !== field
      );
      const updatedBill: AnalyzedBill = {
        ...target,
        verifiedValues,
        userCorrectedFields,
      };
      void revalidateBill(slot, updatedBill);
      return {
        ...prev,
        [slot]: updatedBill,
      };
    });
  };

  const handleSendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: "user",
      content: trimmed,
      timestamp: Date.now(),
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setSending(true);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          languagePreference,
          bills: uploadedBillsList,
          history: historyPayload,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to get answer.");
      }

      const payload = data as ChatResponsePayload;

      // Apply any unambiguous OCR corrections detected in chat
      if (Array.isArray(payload.ocrCorrections) && payload.ocrCorrections.length > 0) {
        setBills((prev) => {
          const updated = { ...prev };
          const touchedSlots = new Set<BillSlotId>();
          for (const corr of payload.ocrCorrections) {
            const target = updated[corr.slotId];
            if (!target) continue;
            const verifiedValues = {
              ...(target.verifiedValues || {}),
              [corr.field]: corr.correctedValue,
            };
            const correctedSet = new Set(target.userCorrectedFields || []);
            correctedSet.add(corr.field);
            updated[corr.slotId] = {
              ...target,
              verifiedValues,
              userCorrectedFields: Array.from(correctedSet),
            };
            touchedSlots.add(corr.slotId);
          }
          touchedSlots.forEach((slot) => {
            const b = updated[slot];
            if (b) void revalidateBill(slot, b);
          });
          return updated;
        });
      }

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: "assistant",
        content: payload.reply,
        timestamp: Date.now(),
        meta: {
          domainCategory: payload.domainCategory,
          detectedIntent: payload.detectedIntent,
          detectedLanguage: payload.detectedLanguage,
          needsClarification: payload.needsClarification,
          clarificationOptions: payload.clarificationOptions,
          answerReliability: payload.answerReliability,
          reliabilityReason: payload.reliabilityReason,
          evidence: payload.evidence,
          ocrCorrections: payload.ocrCorrections,
          pendingConfirmations: payload.pendingConfirmations || [],
          suggestedQuestions: payload.suggestedQuestions,
        },
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      const errorMsg =
        err instanceof Error ? err.message : "Could not reach the server.";
      const fallbackAssistant: ChatMessage = {
        id: `e-${Date.now()}`,
        role: "assistant",
        content: `### Error\n- ${errorMsg}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, fallbackAssistant]);
    } finally {
      setSending(false);
    }
  };

  const handleExplainComparisonInChat = () => {
    const promptByLang: Record<LanguagePreference, string> = {
      auto: "Compare both uploaded electricity bills in detail: total amount, units consumed, billing periods, meter readings, energy charges, fixed charges, taxes, and what increased, decreased, or remained unchanged.",
      en: "Compare both uploaded electricity bills in simple English: total amount, units consumed, billing periods, meter readings, energy charges, fixed charges, taxes, and which charges increased, decreased, or remained unchanged.",
      te: "రెండు విద్యుత్ బిల్లులను తెలుగులో వివరంగా పోల్చి చెప్పండి: మొత్తం బిల్లు, యూనిట్లు, బిల్లింగ్ కాలం, మీటర్ రీడింగ్స్, ఎనర్జీ ఛార్జీలు, ఫిక్స్డ్ ఛార్జీలు, పన్నులు మరియు ఏవి పెరిగాయో, తగ్గాయో, మారలేదో చెప్పండి.",
      hi: "दोनों बिजली बिलों की सरल हिंदी में तुलना करें: कुल राशि, यूनिट खपत, बिलिंग अवधि, मीटर रीडिंग, एनर्जी चार्ज, फिक्स्ड चार्ज, टैक्स और कौन से चार्ज बढ़े, घटे या अपरिवर्तित रहे।",
      tenglish:
        "Rendu electricity bills ni simple Tenglish lo compare chesi cheppandi: total bill amount, units consumed, billing periods, meter readings, energy charges, fixed charges, taxes, mariyu ee charges perigayi, taggayi, leda same ga unnayi.",
    };
    handleSendMessage(promptByLang[languagePreference]);
  };

  return (
    <div className="flex min-h-screen flex-col bg-[#f6f7f9] text-slate-900">
      {/* Top Bar */}
      <header className="border-b border-slate-200 bg-white px-4 py-3 sm:px-6">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-900 text-amber-400">
              <Zap className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-base font-bold tracking-tight text-slate-900">
                BillWise AI
              </h1>
              <p className="text-[11px] text-slate-500">
                Electricity Bill OCR, Charge Breakdown & Multilingual Q&A
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500">
            <span>Supports English · తెలుగు · हिन्दी · Tenglish</span>
          </div>
        </div>
      </header>

      {/* Main Two-Column Workspace */}
      <main className="mx-auto grid w-full max-w-7xl flex-1 grid-cols-1 gap-4 p-4 sm:p-6 lg:grid-cols-12 lg:h-[calc(100vh-65px)]">
        <div className="lg:col-span-5 lg:h-full lg:min-h-0">
          <BillPanel
            bills={bills}
            activeSlot={activeSlot}
            onSelectSlot={setActiveSlot}
            showCompareView={showCompareView}
            onToggleCompareView={setShowCompareView}
            comparison={comparison}
            comparisonLoading={comparisonLoading}
            languagePreference={languagePreference}
            onExplainComparisonInChat={handleExplainComparisonInChat}
            analyzingSlot={analyzingSlot}
            uploadError={uploadError}
            enhanceForOcr={enhanceForOcr}
            onToggleEnhanceForOcr={setEnhanceForOcr}
            onUploadFile={handleUploadFile}
            onRemoveBill={handleRemoveBill}
            onVerifyField={handleVerifyField}
            onRevertField={handleRevertField}
            onAskQuestion={handleSendMessage}
          />
        </div>

        <div className="lg:col-span-7 lg:h-full lg:min-h-0">
          <ChatPanel
            messages={messages}
            sending={sending}
            languagePreference={languagePreference}
            onChangeLanguage={setLanguagePreference}
            onSendMessage={handleSendMessage}
            onConfirmPendingValue={handleVerifyField}
            onClearChat={() => setMessages([])}
            uploadedBills={uploadedBillsList}
          />
        </div>
      </main>
    </div>
  );
}
